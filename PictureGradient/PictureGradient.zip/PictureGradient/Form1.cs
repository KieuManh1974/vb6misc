using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PictureGradient
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.PictureBox pctGradient;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.HScrollBar scrWidth;
		private System.Windows.Forms.HScrollBar scrHeight;
		private System.Windows.Forms.HScrollBar scrRedTop;
		private System.Windows.Forms.HScrollBar scrGreenTop;
		private System.Windows.Forms.HScrollBar scrBlueTop;
		private System.Windows.Forms.HScrollBar scrRedBottom;
		private System.Windows.Forms.HScrollBar scrGreenBottom;
		private System.Windows.Forms.HScrollBar scrBlueBottom;
		private System.Windows.Forms.TextBox txtWidth;
		private System.Windows.Forms.TextBox txtHeight;
		private System.Windows.Forms.TextBox txtRedTop;
		private System.Windows.Forms.TextBox txtGreenTop;
		private System.Windows.Forms.TextBox txtBlueTop;
		private System.Windows.Forms.TextBox txtRedBottom;
		private System.Windows.Forms.TextBox txtGreenBottom;
		private System.Windows.Forms.TextBox txtBlueBottom;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pctGradient = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.scrWidth = new System.Windows.Forms.HScrollBar();
			this.scrHeight = new System.Windows.Forms.HScrollBar();
			this.scrRedTop = new System.Windows.Forms.HScrollBar();
			this.scrGreenTop = new System.Windows.Forms.HScrollBar();
			this.scrBlueTop = new System.Windows.Forms.HScrollBar();
			this.scrRedBottom = new System.Windows.Forms.HScrollBar();
			this.scrGreenBottom = new System.Windows.Forms.HScrollBar();
			this.scrBlueBottom = new System.Windows.Forms.HScrollBar();
			this.txtWidth = new System.Windows.Forms.TextBox();
			this.txtHeight = new System.Windows.Forms.TextBox();
			this.txtRedTop = new System.Windows.Forms.TextBox();
			this.txtGreenTop = new System.Windows.Forms.TextBox();
			this.txtBlueTop = new System.Windows.Forms.TextBox();
			this.txtRedBottom = new System.Windows.Forms.TextBox();
			this.txtGreenBottom = new System.Windows.Forms.TextBox();
			this.txtBlueBottom = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// pctGradient
			// 
			this.pctGradient.Location = new System.Drawing.Point(8, 136);
			this.pctGradient.Name = "pctGradient";
			this.pctGradient.Size = new System.Drawing.Size(192, 176);
			this.pctGradient.TabIndex = 1;
			this.pctGradient.TabStop = false;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(80, 16);
			this.label1.TabIndex = 2;
			this.label1.Text = "Width";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 32);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(80, 16);
			this.label2.TabIndex = 3;
			this.label2.Text = "Height";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 56);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(80, 16);
			this.label3.TabIndex = 4;
			this.label3.Text = "Red";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 80);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(80, 16);
			this.label4.TabIndex = 5;
			this.label4.Text = "Green";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(8, 104);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(80, 16);
			this.label5.TabIndex = 6;
			this.label5.Text = "Blue";
			// 
			// scrWidth
			// 
			this.scrWidth.Location = new System.Drawing.Point(88, 8);
			this.scrWidth.Maximum = 1280;
			this.scrWidth.Minimum = 1;
			this.scrWidth.Name = "scrWidth";
			this.scrWidth.Size = new System.Drawing.Size(184, 16);
			this.scrWidth.TabIndex = 7;
			this.scrWidth.Value = 100;
			this.scrWidth.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrWidth_Scroll);
			// 
			// scrHeight
			// 
			this.scrHeight.Location = new System.Drawing.Point(88, 32);
			this.scrHeight.Maximum = 1024;
			this.scrHeight.Minimum = 1;
			this.scrHeight.Name = "scrHeight";
			this.scrHeight.Size = new System.Drawing.Size(184, 16);
			this.scrHeight.TabIndex = 8;
			this.scrHeight.Value = 100;
			this.scrHeight.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrHeight_Scroll);
			// 
			// scrRedTop
			// 
			this.scrRedTop.Location = new System.Drawing.Point(88, 56);
			this.scrRedTop.Maximum = 255;
			this.scrRedTop.Name = "scrRedTop";
			this.scrRedTop.Size = new System.Drawing.Size(88, 16);
			this.scrRedTop.TabIndex = 9;
			this.scrRedTop.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrRedTop_Scroll);
			// 
			// scrGreenTop
			// 
			this.scrGreenTop.Location = new System.Drawing.Point(88, 80);
			this.scrGreenTop.Maximum = 255;
			this.scrGreenTop.Name = "scrGreenTop";
			this.scrGreenTop.Size = new System.Drawing.Size(88, 16);
			this.scrGreenTop.TabIndex = 10;
			this.scrGreenTop.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrGreenTop_Scroll);
			// 
			// scrBlueTop
			// 
			this.scrBlueTop.Location = new System.Drawing.Point(88, 104);
			this.scrBlueTop.Maximum = 255;
			this.scrBlueTop.Name = "scrBlueTop";
			this.scrBlueTop.Size = new System.Drawing.Size(88, 16);
			this.scrBlueTop.TabIndex = 11;
			this.scrBlueTop.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrBlueTop_Scroll);
			// 
			// scrRedBottom
			// 
			this.scrRedBottom.Location = new System.Drawing.Point(184, 56);
			this.scrRedBottom.Maximum = 255;
			this.scrRedBottom.Name = "scrRedBottom";
			this.scrRedBottom.Size = new System.Drawing.Size(88, 16);
			this.scrRedBottom.TabIndex = 12;
			this.scrRedBottom.Value = 255;
			this.scrRedBottom.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrRedBottom_Scroll);
			// 
			// scrGreenBottom
			// 
			this.scrGreenBottom.Location = new System.Drawing.Point(184, 80);
			this.scrGreenBottom.Maximum = 255;
			this.scrGreenBottom.Name = "scrGreenBottom";
			this.scrGreenBottom.Size = new System.Drawing.Size(88, 16);
			this.scrGreenBottom.TabIndex = 13;
			this.scrGreenBottom.Value = 255;
			this.scrGreenBottom.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrGreenBottom_Scroll);
			// 
			// scrBlueBottom
			// 
			this.scrBlueBottom.Location = new System.Drawing.Point(184, 104);
			this.scrBlueBottom.Maximum = 255;
			this.scrBlueBottom.Name = "scrBlueBottom";
			this.scrBlueBottom.Size = new System.Drawing.Size(88, 16);
			this.scrBlueBottom.TabIndex = 14;
			this.scrBlueBottom.Value = 255;
			this.scrBlueBottom.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar8_Scroll);
			// 
			// txtWidth
			// 
			this.txtWidth.Location = new System.Drawing.Point(296, 8);
			this.txtWidth.Name = "txtWidth";
			this.txtWidth.Size = new System.Drawing.Size(64, 20);
			this.txtWidth.TabIndex = 15;
			this.txtWidth.Text = "";
			// 
			// txtHeight
			// 
			this.txtHeight.Location = new System.Drawing.Point(296, 32);
			this.txtHeight.Name = "txtHeight";
			this.txtHeight.Size = new System.Drawing.Size(64, 20);
			this.txtHeight.TabIndex = 16;
			this.txtHeight.Text = "";
			// 
			// txtRedTop
			// 
			this.txtRedTop.Location = new System.Drawing.Point(296, 56);
			this.txtRedTop.Name = "txtRedTop";
			this.txtRedTop.Size = new System.Drawing.Size(64, 20);
			this.txtRedTop.TabIndex = 17;
			this.txtRedTop.Text = "";
			// 
			// txtGreenTop
			// 
			this.txtGreenTop.Location = new System.Drawing.Point(296, 80);
			this.txtGreenTop.Name = "txtGreenTop";
			this.txtGreenTop.Size = new System.Drawing.Size(64, 20);
			this.txtGreenTop.TabIndex = 18;
			this.txtGreenTop.Text = "";
			// 
			// txtBlueTop
			// 
			this.txtBlueTop.Location = new System.Drawing.Point(296, 104);
			this.txtBlueTop.Name = "txtBlueTop";
			this.txtBlueTop.Size = new System.Drawing.Size(64, 20);
			this.txtBlueTop.TabIndex = 19;
			this.txtBlueTop.Text = "";
			// 
			// txtRedBottom
			// 
			this.txtRedBottom.Location = new System.Drawing.Point(368, 56);
			this.txtRedBottom.Name = "txtRedBottom";
			this.txtRedBottom.Size = new System.Drawing.Size(64, 20);
			this.txtRedBottom.TabIndex = 20;
			this.txtRedBottom.Text = "";
			// 
			// txtGreenBottom
			// 
			this.txtGreenBottom.Location = new System.Drawing.Point(368, 80);
			this.txtGreenBottom.Name = "txtGreenBottom";
			this.txtGreenBottom.Size = new System.Drawing.Size(64, 20);
			this.txtGreenBottom.TabIndex = 21;
			this.txtGreenBottom.Text = "";
			// 
			// txtBlueBottom
			// 
			this.txtBlueBottom.Location = new System.Drawing.Point(368, 104);
			this.txtBlueBottom.Name = "txtBlueBottom";
			this.txtBlueBottom.Size = new System.Drawing.Size(64, 20);
			this.txtBlueBottom.TabIndex = 22;
			this.txtBlueBottom.Text = "";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(712, 614);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.txtBlueBottom,
																		  this.txtGreenBottom,
																		  this.txtRedBottom,
																		  this.txtBlueTop,
																		  this.txtGreenTop,
																		  this.txtRedTop,
																		  this.txtHeight,
																		  this.txtWidth,
																		  this.scrBlueBottom,
																		  this.scrGreenBottom,
																		  this.scrRedBottom,
																		  this.scrBlueTop,
																		  this.scrGreenTop,
																		  this.scrRedTop,
																		  this.scrHeight,
																		  this.scrWidth,
																		  this.label5,
																		  this.label4,
																		  this.label3,
																		  this.label2,
																		  this.label1,
																		  this.pctGradient});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}


		private void cmdGo_Click(object sender, System.EventArgs e)
		{
			RenderGradient();
		}

		private void RenderGradient() 
		{
			Bitmap b = new Bitmap(pctGradient.Width,pctGradient.Height);

			Graphics oFile = Graphics.FromImage(b);
			Graphics oCanvas = pctGradient.CreateGraphics();
			oCanvas.Clear(pctGradient.BackColor);

			for (int iYCoord = 0; iYCoord < pctGradient.Height; iYCoord++) 
			{	
				int iRed = scrRedTop.Value+iYCoord*(scrRedBottom.Value - scrRedTop.Value)/pctGradient.Height;
				int iGreen = scrGreenTop.Value+iYCoord*(scrGreenBottom.Value - scrGreenTop.Value)/pctGradient.Height;
				int iBlue = scrBlueTop.Value+iYCoord*(scrBlueBottom.Value - scrBlueTop.Value)/pctGradient.Height;

				Pen oPen = new System.Drawing.Pen(Color.FromArgb(iRed,iGreen,iBlue));
				oFile.DrawLine(oPen, 0, iYCoord, pctGradient.Width, iYCoord);
				oCanvas.DrawLine(oPen, 0, iYCoord, pctGradient.Width, iYCoord);
			}

			b.Save("gradient.png", System.Drawing.Imaging.ImageFormat.Png);
			
		}


		private void scrWidth_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			txtWidth.Text = scrWidth.Value.ToString();
			pctGradient.Width = scrWidth.Value;
			RenderGradient();
		}

		private void scrHeight_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			txtHeight.Text = scrHeight.Value.ToString();
			pctGradient.Height = scrHeight.Value;
			RenderGradient();
		}

		private void scrRedTop_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			txtRedTop.Text = scrRedTop.Value.ToString();
			RenderGradient();
		}

		private void scrRedBottom_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			txtRedBottom.Text = scrRedBottom.Value.ToString();
			RenderGradient();
		}

		private void scrGreenTop_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			txtGreenTop.Text = scrGreenTop.Value.ToString();
			RenderGradient();
		}

		private void scrGreenBottom_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			txtGreenBottom.Text = scrGreenBottom.Value.ToString();
			RenderGradient();
		}

		private void scrBlueTop_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			txtBlueTop.Text = scrBlueTop.Value.ToString();
			RenderGradient();
		}

		private void hScrollBar8_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
		{
			txtBlueBottom.Text = scrBlueBottom.Value.ToString();
			RenderGradient();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			RenderGradient();
		}



	}
}
