http://www.vb-helper.com/HowTo/picchng2.zip

Solution to picture changing animations contest (http://www.vb-helper.com/HowTo/picchng.zip).

These solutions were created by Neil Crosby (ncrosby@swbell.net).

	Disclaimer
This example program is provided "as is" with no warranty of any kind. It is
intended for demonstration purposes only. In particular, it does no error
handling. You can use the example in any form, but please mention
www.vb-helper.com.
