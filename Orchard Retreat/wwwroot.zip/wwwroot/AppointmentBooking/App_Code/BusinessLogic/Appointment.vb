' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

''' <summary>
''' The Appointment class is used to represent an appointment that a user can make in the Appointment Booking system.
''' </summary>
Public Class Appointment

#Region "Private Variables"

  Private _Id As Integer
  Private _UserName As String = String.Empty
  Private _UserEmailAddress As String = String.Empty
  Private _StartDate As DateTime = DateTime.MinValue
  Private _EndDate As DateTime = DateTime.MinValue
  Private _Comments As String = String.Empty
  Private _BookingObjectId As Integer = -1

#End Region

#Region "Public Properties"

  ''' <summary>
  ''' Gets or sets the Id of the Appointment.
  ''' </summary>
  ''' <returns>Returns -1 when the appointment is new and has not been saved in the database. Returns the Id of the Appointment in the database otherwise.</returns>
  Public Property Id() As Integer
    Get
      Return _Id
    End Get
    Set(ByVal value As Integer)
      _Id = value
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets the name of the user that made this appointment.
  ''' </summary>
  Public Property UserName() As String
    Get
      Return _UserName
    End Get
    Set(ByVal value As String)
      _UserName = value
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets the email address of the user that made this appointment.
  ''' </summary>
  Public Property UserEmailAddress() As String
    Get
      Return _UserEmailAddress
    End Get
    Set(ByVal value As String)
      _UserEmailAddress = value
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets the comments that the user added for this appointment.
  ''' </summary>
  Public Property Comments() As String
    Get
      Return _Comments
    End Get
    Set(ByVal value As String)
      _Comments = value
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets the start date and time for this appointment.
  ''' </summary>
  Public Property StartDate() As DateTime
    Get
      Return _StartDate
    End Get
    Set(ByVal value As DateTime)
      _StartDate = value
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets the end date and time for this appointment.
  ''' </summary>
  Public Property EndDate() As DateTime
    Get
      Return _EndDate
    End Get
    Set(ByVal value As DateTime)
      _EndDate = value
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets the Id of the BookingObject that this appointment was booked against.
  ''' </summary>
  Public Property BookingObjectId() As Integer
    Get
      Return _BookingObjectId
    End Get
    Set(ByVal value As Integer)
      _BookingObjectId = value
    End Set
  End Property

#End Region

End Class
