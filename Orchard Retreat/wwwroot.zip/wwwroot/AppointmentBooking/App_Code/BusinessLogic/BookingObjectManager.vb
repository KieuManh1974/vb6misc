' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Imports System.Data

''' <summary>
''' The BookingObjectManager class is responsible for getting and creating BookingObjects.
''' It's also capable of retrieving information about the available WeekDays in the database.
''' </summary>
''' <remarks>Because this class contains only Shared methods, its constructor has been marked as 
''' Private so no instances of this class can be instantiated.
''' </remarks>
Public Class BookingObjectManager

  ''' <summary>
  ''' Hide the constructor to avoid instances of the BookingObjectManager class.
  ''' </summary>
  Private Sub New()
  End Sub

  ''' <summary>
  ''' Returns a list of available BookingObjects as a DataSet by calling into the BookingObjectManagerDB class.
  ''' </summary>
  ''' <returns>A DataSet with the available BookingObjects holding two columns: The Id and Title for each BookingObject.</returns>
  Public Shared Function GetBookingObjectList() As DataSet
    Return BookingObjectManagerDB.GetBookingObjectList()
  End Function

  ''' <summary>
  ''' Returns a single BookingObject instance by its Id by calling into the BookingObjectManagerDB class.
  ''' </summary>
  ''' <param name="id">The Id of the BookingObject in the database.</param>
  ''' <returns>The requested BookingObject or <see langword="null" /> when the item could not be found in the database.</returns>
  Public Shared Function GetBookingObject(ByVal id As Integer) As BookingObject
    Return BookingObjectManagerDB.GetBookingObject(id)
  End Function

  ''' <summary>
  ''' Saves a new or an existing BookingObject in the database.
  ''' </summary>
  ''' <param name="myBookingObject">The BookingObject that must be saved. When <see cref="BookingObject.Id" /> is -1, a new item is created, otherwise an existing instance is updated.</param>
  Public Shared Sub SaveBookingObject(ByVal myBookingObject As BookingObject)
    BookingObjectManagerDB.SaveBookingObject(myBookingObject)
  End Sub

  ''' <summary>
  ''' Returns a list with the available WorkingDays by calling into the BookingObjectManagerDB class.
  ''' </summary>
  ''' <returns>A DataSet with the available WorkingDays holding two columns: the Id and the Description of the WorkingDay.</returns>
  Public Shared Function GetWorkingDays() As DataSet
    Return BookingObjectManagerDB.GetWorkingDays
  End Function

End Class
