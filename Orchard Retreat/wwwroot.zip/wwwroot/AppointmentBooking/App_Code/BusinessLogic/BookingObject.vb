' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

''' <summary>
''' The BookingObject class represents an entity that can be booked through the Appointment Booking system.
''' To make the application flexible, a generic name has been chosen, instead of something explicit like
''' Hairdresser or ConferenceRoom. Application configuration allows an administrator to define
''' the user-friendly name of the BookingObject.
''' </summary>
Public Class BookingObject

#Region "Private Variables"

  Private _Id As Integer = -1
  Private _Title As String = String.Empty
  Private _StartTime As Integer = -1
  Private _EndTime As Integer = -1
  Private _AvailableOnWeekdays As Weekdays

#End Region

#Region "Public Properties"

  ''' <summary>
  ''' Gets or sets the Id of the BookingObject in the database.
  ''' </summary>
  ''' <returns>An Integer holding the Id of the BookingObject in the database when the BookingObject has been saved, or -1 for a new and unsaved BookingObject.</returns>
  Public Property Id() As Integer
    Get
      Return _Id
    End Get
    Set(ByVal value As Integer)
      _Id = value
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets a short title / description for the BookingObject like "Conference Room 2"
  ''' </summary>
  Public Property Title() As String
    Get
      Return _Title
    End Get
    Set(ByVal value As String)
      ' Make sure we're not storing a value longer than the database can hold
      If value.Length > 100 Then
        value = value.Substring(0, 100)
      End If
      _Title = value
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets the first hour of the day this BookingObject is available.
  ''' </summary>
  Public Property StartTime() As Integer
    Get
      Return _StartTime
    End Get
    Set(ByVal value As Integer)
      If value < 0 Then
        Throw New ArgumentException("StartTime cannot be less than zero.")
      End If
      _StartTime = value
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets the last hour of the day this BookingObject is available.
  ''' </summary>
  Public Property EndTime() As Integer
    Get
      Return _EndTime
    End Get
    Set(ByVal value As Integer)
      If value > 23 Then
        Throw New ArgumentException("EndTime cannot be greater than 23.")
      End If
      _EndTime = value
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets an Enum of type Weekdays to store the available weekdays for this BookingObject.
  ''' </summary>
  ''' <remarks><example>To store multple days, use Or. For example: <br /><code>Weekdays.Sunday Or Weekdays.Monday</code></example></remarks>
  Public Property AvailableOnWeekdays() As Weekdays
    Get
      Return _AvailableOnWeekdays
    End Get
    Set(ByVal value As Weekdays)
      _AvailableOnWeekdays = value
    End Set
  End Property

#End Region

End Class

