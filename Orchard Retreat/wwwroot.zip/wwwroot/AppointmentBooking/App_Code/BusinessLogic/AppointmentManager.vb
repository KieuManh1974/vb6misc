' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Imports System.Data

''' <summary>
''' The AppointmentManager class is responsible for Checking, Getting and Creating appointments.
''' It's also capable of retrieving availability information of appointments.
''' </summary>
''' <remarks>Because this class contains only Shared methods, its constructor has been marked as Private so no instances of this class can be instantiated.</remarks>
Public Class AppointmentManager

  ''' <summary>
  ''' Hide the constructor to avoid instances of the AppointmentManager class.
  ''' </summary>
  Private Sub New()
  End Sub

  ''' <summary>
  ''' Returns all BookingObjects and Appointments for a specified date as two DataTables with a relation in a DataSet by calling into the AppointmentManagerDB class.
  ''' </summary>
  ''' <param name="selectedDate">The date for which the appointments must be retrieved.</param>
  ''' <returns>A DataSet with two datatables, one with the BookingObjects, the other with the associated Appointments.</returns>
  Public Shared Function GetAppointmentList(ByVal selectedDate As DateTime) As DataSet
    Return AppointmentManagerDB.GetAppointmentList(selectedDate)
  End Function

  ''' <summary>
  ''' Returns a single Appointment instance based on its Id by calling into the AppointmentManagerDB class.
  ''' </summary>
  ''' <param name="id">The Id of the appointment in the database.</param>
  ''' <returns>The requested appointment when the item was found in the database, or <see langword="null" /> when the item could not be found.</returns>
  Public Shared Function GetAppointment(ByVal id As Integer) As Appointment
    Return AppointmentManagerDB.GetAppointment(id)
  End Function

  ''' <summary>
  ''' Validates the current appointment to make sure it doesn't overlap with other 
  ''' appointments for the requested BookingObject.
  ''' </summary>
  ''' <param name="myAppointment">The Appointment that needs to be validated.</param>
  ''' <returns>Returns True when the appointment does not overlap with an existing apppointment, and False otherwise.</returns>
  Public Shared Function CheckAppointment(ByVal myAppointment As Appointment) As Boolean
    Return AppointmentManagerDB.CheckAppointment(myAppointment)
  End Function

  ''' <summary>
  ''' Saves an appointment in the database by calling into the AppointmentManagerDB class.
  ''' </summary>
  ''' <param name="myAppointment">The appointment that must be saved.</param>
  ''' <returns>Returns True when the requested date and time was available, and the Appointment was saved successfully.
  ''' Returns False otherwise.</returns>
  Public Shared Function CreateAppointment(ByVal myAppointment As Appointment) As Boolean
    Return AppointmentManagerDB.CreateAppointment(myAppointment)
  End Function

  ''' <summary>
  ''' Returns all BookingObjects and Appointments as two DataTables with a relation in a DataSet by calling into the AppointmentManagerDB class.
  ''' </summary>
  ''' <param name="selectedDate">The date the appointments should be retrieved for.</param>
  ''' <returns>A DataSet with two datatables, one with the BookingObjects, the other with the associated Appointments.</returns>
  Public Shared Function GetTimeSheet(ByVal selectedDate As DateTime) As DataSet
    Return AppointmentManagerDB.GetTimeSheet(selectedDate)
  End Function

End Class
