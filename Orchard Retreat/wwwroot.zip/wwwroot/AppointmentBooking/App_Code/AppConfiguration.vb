' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

''' <summary>
''' The Configuration class exposes public and read-only properties for configuration purposes.
''' </summary>
Public Class AppConfiguration

  ''' <summary>
  ''' Hide the constructor to avoid instances of the AppConfiguration class.
  ''' </summary>
  Private Sub New()
  End Sub

  ''' <summary>
  ''' Returns the connection string for the Appointment Booking system.
  ''' </summary>
  Public Shared ReadOnly Property ConnectionString() As String
    Get
      Dim tempValue As String = "server=(local)\SqlExpress;AttachDbFileName=|DataDirectory|aspnetdb.mdf;Integrated Security=true;User Instance=true"
      Try
        If ConfigurationManager.ConnectionStrings("AppointmentBooking") IsNot Nothing Then
          tempValue = ConfigurationManager.ConnectionStrings("AppointmentBooking").ConnectionString
        End If
      Catch
        ' When we can't get the settting from the config file, ignore the error and return 
        ' the default connection string that points to the instance SqlExpress on the local 
        ' machine and tries to attach the database AppointmentBooking automatically.
      End Try
      Return tempValue
    End Get
  End Property

  ''' <summary>
  ''' Gets the value that determines whether comments are required in an appointment request.
  ''' </summary>
  Public Shared ReadOnly Property RequireCommentsInRequest() As Boolean
    Get
      Dim tempValue As Boolean = True
      Try
        If ConfigurationManager.AppSettings.Get("RequireCommentsInRequest") IsNot Nothing Then
          tempValue = Convert.ToBoolean(ConfigurationManager.AppSettings.Get("RequireCommentsInRequest"))
        End If
      Catch
        ' Ignore the error, and return the default value for tempValue
      End Try
      Return tempValue
    End Get
  End Property

  ''' <summary>
  ''' Gets the singular form of the user-friendly name of the Booking Object.
  ''' </summary>
  Public Shared ReadOnly Property BookingObjectNameSingular() As String
    Get
      Dim tempValue As String = String.Empty
      Try
        If ConfigurationManager.AppSettings.Get("BookingObjectNameSingular") IsNot Nothing Then
          tempValue = ConfigurationManager.AppSettings.Get("BookingObjectNameSingular")
        End If
      Catch
        ' Pass up the erorr
        Throw
      End Try
      Return tempValue
    End Get
  End Property

  ''' <summary>
  ''' Gets the plural form of the user-friendly name of the Booking Object.
  ''' </summary>
  Public Shared ReadOnly Property BookingObjectNamePlural() As String
    Get
      Dim tempValue As String = String.Empty
      Try
        If ConfigurationManager.AppSettings.Get("BookingObjectNamePlural") IsNot Nothing Then
          tempValue = ConfigurationManager.AppSettings.Get("BookingObjectNamePlural")
        End If
      Catch
        ' Pass up the erorr
        Throw
      End Try
      Return tempValue
    End Get
  End Property
End Class
