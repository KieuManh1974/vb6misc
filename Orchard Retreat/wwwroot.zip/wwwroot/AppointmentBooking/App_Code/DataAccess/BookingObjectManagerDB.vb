' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Imports System.Data
Imports System.Data.SqlClient
Imports System.Security

Public Class BookingObjectManagerDB

  ''' <summary>
  ''' Hide the constructor to avoid instances of the BookingObjectManagerDB class.
  ''' </summary>
  Private Sub New()
  End Sub

  ''' <summary>
  ''' Returns a list of available BookingObjects as a DataSet by querying the database.
  ''' </summary>
  ''' <returns>A DataSet with the available BookingObjects holding two columns: The Id and Title for each BookingObject.</returns>
  Public Shared Function GetBookingObjectList() As DataSet
    Dim myDataSet As DataSet = New DataSet()

    Try
      Using myConnection As New SqlConnection(AppConfiguration.ConnectionString)
        Dim myCommand As SqlCommand = New SqlCommand("sprocBookingObjectSelectList", myConnection)
        myCommand.CommandType = CommandType.StoredProcedure

        Dim myDataAdapter As SqlDataAdapter = New SqlDataAdapter()
        myDataAdapter.SelectCommand = myCommand
        myDataAdapter.Fill(myDataSet)
        myConnection.Close()
        Return myDataSet
      End Using
    Catch ex As Exception
      ' Pass up the error; it will be caught by the code in the Global.asax and the generic error page set up in web.config.
      Throw
    End Try
  End Function

  ''' <summary>
  ''' Returns a single BookingObject instance by its Id by querying the database.
  ''' </summary>
  ''' <param name="id">The Id of the BookingObject in the database.</param>
  ''' <returns>The requested BookingObject or <see langword="null" /> when the item could not be found in the database.</returns>
  Public Shared Function GetBookingObject(ByVal id As Integer) As BookingObject
    Dim myBookingObject As BookingObject = Nothing

    Try
      Using myConnection As New SqlConnection(AppConfiguration.ConnectionString)
        Dim myCommand As SqlCommand = New SqlCommand("sprocBookingObjectSelectSingleItem", myConnection)
        myCommand.CommandType = CommandType.StoredProcedure

        myCommand.Parameters.AddWithValue("@id", id)

        myConnection.Open()
        Using myReader As SqlDataReader = _
              myCommand.ExecuteReader(CommandBehavior.CloseConnection)
          If myReader.Read() Then
            myBookingObject = New BookingObject()
            myBookingObject.Id = myReader.GetInt32(myReader.GetOrdinal("Id"))
            myBookingObject.Title = myReader.GetString(myReader.GetOrdinal("Title"))
            myBookingObject.StartTime = Convert.ToDateTime(myReader.GetValue(myReader.GetOrdinal("StartTime"))).Hour
            myBookingObject.EndTime = Convert.ToDateTime(myReader.GetValue(myReader.GetOrdinal("EndTime"))).Hour
          End If
          myReader.Close()

          If myBookingObject IsNot Nothing Then
            ' Get the available working days assoiated with this BookingObject
            myCommand = New SqlCommand("sprocBookingObjectSelectWeekdays", myConnection)
            myCommand.CommandType = CommandType.StoredProcedure
            myCommand.Parameters.AddWithValue("@id", id)
            myConnection.Open()
            Using myWeekdayReader As SqlDataReader = _
                  myCommand.ExecuteReader(CommandBehavior.CloseConnection)
              ' Set the flags for the selected WeekDays
              While myWeekdayReader.Read()
                Select Case myWeekdayReader.GetInt32(0)
                  Case 1
                    myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Sunday
                  Case 2
                    myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Monday
                  Case 3
                    myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Tuesday
                  Case 4
                    myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Wednesday
                  Case 5
                    myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Thursday
                  Case 6
                    myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Friday
                  Case 7
                    myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Saturday
                End Select
              End While
            End Using
          End If
        End Using
      End Using
    Catch
      Throw
    Finally
    End Try
    Return myBookingObject
  End Function

  ''' <summary>
  ''' Saves a new or an existing BookingObject in the database by executing a stored procedure.
  ''' </summary>
  ''' <param name="myBookingObject">The BookingObject that must be saved. When <see cref="BookingObject.Id" /> is -1, a new item is created, otherwise an existing instance is updated.</param>
  Public Shared Sub SaveBookingObject(ByVal myBookingObject As BookingObject)
    Try
      Using myConnection As New SqlConnection(AppConfiguration.ConnectionString)
        Dim myCommand As SqlCommand = New SqlCommand("sprocBookingObjectInsertUpdateSingleItem", myConnection)
        myCommand.CommandType = CommandType.StoredProcedure

        Dim myDataAdapter As SqlDataAdapter = New SqlDataAdapter()
        myDataAdapter.SelectCommand = myCommand

        If myBookingObject.Id = -1 Then
          myCommand.Parameters.AddWithValue("@id", DBNull.Value)
        Else
          myCommand.Parameters.AddWithValue("@id", myBookingObject.Id)
        End If

        myCommand.Parameters.AddWithValue("@title", myBookingObject.Title)
        myCommand.Parameters.AddWithValue("@startTime", myBookingObject.StartTime)
        myCommand.Parameters.AddWithValue("@endTime", myBookingObject.EndTime)

        ' Add the boolean value for each weekday in the AvailableOnWeekdays property.
        myCommand.Parameters.AddWithValue("@sunday", Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Sunday))
        myCommand.Parameters.AddWithValue("@monday", Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Monday))
        myCommand.Parameters.AddWithValue("@tuesday", Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Tuesday))
        myCommand.Parameters.AddWithValue("@wednesday", Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Wednesday))
        myCommand.Parameters.AddWithValue("@thursday", Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Thursday))
        myCommand.Parameters.AddWithValue("@friday", Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Friday))
        myCommand.Parameters.AddWithValue("@saturday", Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Saturday))

        myConnection.Open()
        myCommand.ExecuteNonQuery()
        myConnection.Close()

      End Using
    Catch ex As Exception
      ' Pass up the error; it will be caught by the code in the Global.asax and the generic error page set up in web.config.
      Throw
    End Try
  End Sub

  ''' <summary>
  ''' Returns a list with the available WorkingDays by querying the database.
  ''' </summary>
  ''' <returns>A DataSet with the available WorkingDays holding two columns: the Id and the Description of the WorkingDay.</returns>
  Public Shared Function GetWorkingDays() As DataSet
    Dim myDataSet As DataSet = New DataSet()
    Try
      Using myConnection As New SqlConnection(AppConfiguration.ConnectionString)
        Dim myCommand As SqlCommand = New SqlCommand("sprocWorkingDaysSelectList", myConnection)
        myCommand.CommandType = CommandType.StoredProcedure

        Dim myDataAdapter As SqlDataAdapter = New SqlDataAdapter()
        myDataAdapter.SelectCommand = myCommand
        myDataAdapter.Fill(myDataSet)
        myConnection.Close()

        Return myDataSet
      End Using
    Catch ex As Exception
      ' Pass up the error; it will be caught by the code in the Global.asax and the generic error page set up in web.config.
      Throw
    End Try

  End Function

End Class
