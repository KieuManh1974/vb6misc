' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Imports System.Data
Imports System.Data.SqlClient

''' <summary>
''' The AppointmentManagerDB class is responsible for Checking, Getting and Creating appointments from the database.
''' It's also capable of retrieving availability information of appointments.
''' </summary>
''' <remarks>Because this class contains only Shared methods, its constructor has been marked as Private so no instances of this class can be instantiated.</remarks>
Public Class AppointmentManagerDB

  ''' <summary>
  ''' Hide the constructor to avoid instances of the AppointmentManagerDB class.
  ''' </summary>
  Private Sub New()
  End Sub

  ''' <summary>
  ''' Returns all BookingObjects and Appointments as two DataTables with a relation in a DataSet by querying the database.
  ''' </summary>
  ''' <param name="selectedDate">The date the appointments should be retrieved for.</param>
  Public Shared Function GetAppointmentList(ByVal selectedDate As DateTime) As DataSet
    Dim myDataSet As DataSet = New DataSet()

    Using myConnection As New SqlConnection(AppConfiguration.ConnectionString)
      Try
        Dim myCommand As SqlCommand = New SqlCommand("sprocAppointmentSelectList", myConnection)
        myCommand.CommandType = CommandType.StoredProcedure

        myCommand.Parameters.AddWithValue("@selectedDate", selectedDate)

        Dim myDataAdapter As SqlDataAdapter = New SqlDataAdapter()
        myDataAdapter.SelectCommand = myCommand
        myDataAdapter.Fill(myDataSet)

        ' Explicitly name each table to we can create the relation with table names,
        ' and not with "magic numbers".
        myDataSet.Tables(0).TableName = "BookingObject"
        myDataSet.Tables(1).TableName = "Appointment"

        myDataSet.Relations.Add("BookingObjectAppointment", myDataSet.Tables("BookingObject").Columns("Id"), _
                         myDataSet.Tables("Appointment").Columns("BookingObjectId"))

        Return myDataSet
      Catch ex As Exception
        ' Pass up the error; it will be caught by the code in the Global.asax and the generic error page set up in web.config.
        Throw
      Finally
        myConnection.Close()
      End Try
    End Using
  End Function

  ''' <summary>
  ''' Returns a single Appointment instance based on its Id by querying the database.
  ''' </summary>
  ''' <param name="id">The Id of the appointment in the database.</param>
  ''' <returns>The requested appointment when the item was found in the database, or <see langword="null" /> when the item could not be found.</returns>
  Public Shared Function GetAppointment(ByVal id As Integer) As Appointment
    Dim myAppointment As Appointment = Nothing

    Try
      Using myConnection As New SqlConnection(AppConfiguration.ConnectionString)
        Dim myCommand As SqlCommand = New SqlCommand("sprocAppointmentSelectSingleItem", myConnection)
        myCommand.CommandType = CommandType.StoredProcedure

        myCommand.Parameters.AddWithValue("@id", id)

        myConnection.Open()
        Using myReader As SqlDataReader = _
              myCommand.ExecuteReader(CommandBehavior.CloseConnection)
          If myReader.Read() Then
            myAppointment = New Appointment()
            myAppointment.Id = myReader.GetInt32(myReader.GetOrdinal("Id"))
            myAppointment.StartDate = Convert.ToDateTime(myReader.GetValue(myReader.GetOrdinal("StartDate")))
            myAppointment.EndDate = Convert.ToDateTime(myReader.GetValue(myReader.GetOrdinal("EndDate")))
            myAppointment.BookingObjectId = Convert.ToInt32(myReader.GetValue(myReader.GetOrdinal("BookingObjectId")))
            If myReader.GetValue(myReader.GetOrdinal("Comments")) IsNot DBNull.Value Then
              myAppointment.Comments = myReader.GetValue(myReader.GetOrdinal("Comments")).ToString()
            End If
            myAppointment.UserName = myReader.GetValue(myReader.GetOrdinal("UserName")).ToString()
            myAppointment.UserEmailAddress = myReader.GetValue(myReader.GetOrdinal("UserEmailAddress")).ToString()
          End If
          myReader.Close()

        End Using
      End Using
    Catch
      Throw
    Finally

    End Try
    Return myAppointment
  End Function

  ''' <summary>
  ''' Validates the current appointment by calling a storred procedure to make sure it 
  ''' doesn't overlap with other appointments for the requested BookingObject.
  ''' </summary>
  ''' <param name="myAppointment">The Appointment that needs to be checked.</param>
  ''' <returns>Returns True when the appointment does not overlap with an existing apppointment, and False otherwise.</returns>
  Public Shared Function CheckAppointment(ByVal myAppointment As Appointment) As Boolean
    Try
      Using myConnection As New SqlConnection(AppConfiguration.ConnectionString)
        Dim myCommand As SqlCommand = New SqlCommand("sprocAppointmentCheckAvailability", myConnection)
        myCommand.CommandType = CommandType.StoredProcedure

        myCommand.Parameters.AddWithValue("@bookingObjectId", myAppointment.BookingObjectId)
        myCommand.Parameters.AddWithValue("@startDate", myAppointment.StartDate)
        myCommand.Parameters.AddWithValue("@endDate", myAppointment.EndDate)

        Try
          myConnection.Open()

          ' The stored procedure returns the umber of available time slots for the appointment.
          ' 0 means the time is not available, a positive number means the appointment can be booked.
          Return Convert.ToInt32(myCommand.ExecuteScalar()) > 0
        Catch ex As Exception
          Throw
        Finally
          myConnection.Close()
        End Try
      End Using
    Catch ex As Exception
      ' Pass up the error; it will be caught by the code in the Global.asax and the generic error page set up in web.config.
      Throw
    End Try
  End Function

  ''' <summary>
  ''' Saves an appointment in the database by executing a stored procedure.
  ''' </summary>
  ''' <param name="myAppointment">The <see cref="Appointment" /> that must be saved.</param>
  ''' <remarks>For safety reasons, this method calls CheckAppointment again to ensure the 
  ''' appointment will not overlap with other appointments.</remarks>
  ''' <returns>Returns True when the requested date and time was available, and the Appointment was saved successfully.
  ''' Returns False otherwise.</returns>
  Public Shared Function CreateAppointment(ByVal myAppointment As Appointment) As Boolean
    ' Make sure the appointment doesn't overlap
    If CheckAppointment(myAppointment) Then
      Try
        Using myConnection As New SqlConnection(AppConfiguration.ConnectionString)
          Dim myCommand As SqlCommand = New SqlCommand("sprocAppointmentInsertSingleItem", myConnection)
          myCommand.CommandType = CommandType.StoredProcedure

          myCommand.Parameters.AddWithValue("@userName", myAppointment.UserName)
          myCommand.Parameters.AddWithValue("@userEmailAddress", myAppointment.UserEmailAddress)
          myCommand.Parameters.AddWithValue("@startDate", myAppointment.StartDate)
          myCommand.Parameters.AddWithValue("@endDate", myAppointment.EndDate)
          If myAppointment.Comments.Length > 0 Then
            myCommand.Parameters.AddWithValue("@comments", myAppointment.Comments)
          Else
            myCommand.Parameters.AddWithValue("@comments", DBNull.Value)
          End If
          myCommand.Parameters.AddWithValue("@bookingObjectId", myAppointment.BookingObjectId)

          Try
            myConnection.Open()
            myCommand.ExecuteNonQuery()
          Catch ex As Exception
            Throw
          Finally
            myConnection.Close()
          End Try
        End Using
      Catch ex As Exception
        ' Pass up the error; it will be caught by the code in the Global.asax and the generic error page set up in web.config.
        Throw
      End Try

      Return True
    Else
      Return False
    End If
  End Function

  ''' <summary>
  ''' Returns all BookingObjects and Appointments as two DataTables with a relation in a DataSet by querying the database.
  ''' </summary>
  ''' <param name="selectedDate">The date the appointments should be retrieved for.</param>
  Public Shared Function GetTimeSheet(ByVal selectedDate As DateTime) As DataSet
    Dim myDataSet As DataSet = New DataSet()

    Using myConnection As New SqlConnection(AppConfiguration.ConnectionString)
      Try
        Dim myCommand As SqlCommand = _
                New SqlCommand("sprocTimesheetSelectList", myConnection)
        myCommand.CommandType = CommandType.StoredProcedure

        myCommand.Parameters.AddWithValue("@selectedDate", selectedDate)

        Dim myDataAdapter As SqlDataAdapter = New SqlDataAdapter()
        myDataAdapter.SelectCommand = myCommand
        myDataAdapter.Fill(myDataSet)

        myDataSet.Tables(0).TableName = "BookingObject"
        myDataSet.Tables(1).TableName = "Appointment"

        myDataSet.Relations.Add("BookingObjectAppointment", _
            myDataSet.Tables("BookingObject").Columns("Id"), _
            myDataSet.Tables("Appointment").Columns("BookingObjectId"))

        Return myDataSet
      Catch ex As Exception
        Throw
      Finally
        myConnection.Close()
      End Try
    End Using
  End Function


End Class
