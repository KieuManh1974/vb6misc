' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

''' <summary>
''' The Helpers class contains helper members that can be used throughout the application without being tied to the Business or Data Access layer.
''' </summary>
''' <remarks>Because this class contains only Shared methods, its constructor has been marked as Private so no instances of this class can be instantiated.</remarks>
Public Class Helpers

  ''' <summary>
  ''' Hide the constructor to avoid instances of the Helpers class.
  ''' </summary>
  Private Sub New()
  End Sub

  ''' <summary>
  ''' Returns a string with the current protocol and server name. E.g. http://www.SomeSite.nl or http://localhost:2175
  ''' </summary>
  ''' <remarks>
  ''' This property is useful if you want to know the current site in a dynamic environment, 
  ''' as is the case with the ASP.NET Development Server with dynamic ports or with
  ''' IIS in a site with multiple host header definitions.
  '''</remarks>
  Public Shared ReadOnly Property GetCurrentServerRoot() As String
    Get
      Dim protocol As String = String.Empty
      Dim siteName As String
      If Not HttpContext.Current.Request.ServerVariables.Get("SERVER_PORT") = "1" Then
        protocol = "http://"
      Else
        protocol = "https://"
      End If
      siteName = HttpContext.Current.Request.ServerVariables.Get("HTTP_HOST")

      Return protocol & siteName
    End Get
  End Property
End Class
