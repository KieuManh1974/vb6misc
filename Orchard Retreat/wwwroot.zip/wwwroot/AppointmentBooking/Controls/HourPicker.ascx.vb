' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

''' <summary>
''' The HourPicker displays a custom DropDownList with hours. The first and the last hour in the list can
''' be set with the StartTime and EndTime properties.
''' </summary>
Partial Class HourPicker
  Inherits System.Web.UI.UserControl

  ''' <summary>
  ''' Gets or sets the selected hour of the DropDownList.
  ''' </summary>
  ''' <returns>An Integer value representing the selected hour, or -1 when no hour has been selected.</returns>
  Public Property SelectedHour() As Integer
    Get
      If lstHour.SelectedIndex >= 0 Then
        Return Convert.ToInt32(lstHour.SelectedValue)
      Else
        Return -1
      End If
    End Get
    Set(ByVal value As Integer)
      If lstHour.Items.FindByValue(value.ToString()) IsNot Nothing Then
        lstHour.Items.FindByValue(value.ToString()).Selected = True
      End If
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets the first available hour in the DropDownList.
  ''' </summary>
  ''' <remarks>The value for this property must be between 0 and 23.</remarks>
  Public Property StartTime() As Integer
    Get
      If ViewState("StartTime") IsNot Nothing Then
        Return Convert.ToInt32(ViewState("StartTime"))
      Else
        Return 0
      End If
    End Get
    Set(ByVal value As Integer)
      If value >= 0 And value <= 23 Then
        ViewState("StartTime") = value
        CreateListItems()
      Else
        Throw New ArgumentOutOfRangeException("StartTime", "StartTime must be between 0 and 23")
      End If
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets the last available hour in the DropDownList.
  ''' </summary>
  ''' <remarks>The value for this property must be between 0 and 23.</remarks>
  Public Property EndTime() As Integer
    Get
      If ViewState("EndTime") IsNot Nothing Then
        Return Convert.ToInt32(ViewState("EndTime"))
      Else
        Return 23
      End If
    End Get
    Set(ByVal value As Integer)
      If value >= 0 And value <= 23 Then
        ViewState("EndTime") = value
        CreateListItems()
      Else
        Throw New ArgumentOutOfRangeException("EndTime", "EndTime must be between 0 and 23")
      End If
    End Set
  End Property

  ''' <summary>
  ''' Creates the list by adding values for each hour between StartTime and EndTime.
  ''' </summary>
  ''' <remarks>This method is called whenever StartTime or EndTime is updated to ensure the list is always in sync with those properties.</remarks>
  Private Sub CreateListItems()
    lstHour.Items.Clear()
    For i As Integer = StartTime To EndTime
      lstHour.Items.Add(New ListItem(i.ToString() & ":00", i.ToString()))
    Next
  End Sub

End Class
