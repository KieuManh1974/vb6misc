' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Partial Class Controls_MainMenu
  Inherits System.Web.UI.UserControl

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    ' Determine which menu item must be selected by looking at the filename for the current request.
    Select Case Request.AppRelativeCurrentExecutionFilePath.ToLower()
      Case "~/default.aspx"
        lnkHome.CssClass = "Selected"
      Case "~/checkavailability.aspx"
        lnkCheckAvailability.CssClass = "Selected"
      Case "~/createappointment.aspx"
        lnkMakeAppointment.CssClass = "Selected"
      Case "~/signup.aspx"
        lnkSignUp.CssClass = "Selected"
      Case "~/login.aspx"
        If Context.User.Identity.IsAuthenticated = False Then
          ' Only do this when the user is not logged in. Otherwise, the Logout link is
          ' visible, which cannot be given the Selected style, because the user is redirected to the
          ' home page after logging out.
          Dim myHyperLink As HyperLink = CType(lvLogin.FindControl("lnkLogin"), HyperLink)
          myHyperLink.CssClass = "Selected"
        End If
      Case Else
        ' Handle all other pages in the Management section
        If Request.AppRelativeCurrentExecutionFilePath.ToLower().Contains("~/management") Then
          lnkManagement.CssClass = "Selected"
        End If
    End Select
  End Sub
End Class
