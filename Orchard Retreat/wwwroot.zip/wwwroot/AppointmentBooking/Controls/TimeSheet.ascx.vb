' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Imports System.Data

''' <summary>
''' The TimeSheet class is capable of display an Availability sheet with BookingObjects and their appointments.
''' </summary>
Partial Class TimeSheet
  Inherits System.Web.UI.UserControl

  Private _DataSource As DataSet = Nothing
  Private _StartTime As Integer = 0
  Private _EndTime As Integer = 23
  Private _SelectedDate As Date = DateTime.MinValue

  ''' <summary>
  ''' Gets or sets the DataSource for the TimeSheet control.
  ''' </summary>
  ''' <value>A DataSet holding two results sets for the BookingObjects and the Appointments.</value>
  Public Property DataSource() As DataSet
    Get
      Return _DataSource
    End Get
    Set(ByVal value As DataSet)
      _DataSource = value
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets the date currently used to display the TimeSheet.
  ''' </summary>
  Public Property SelectedDate() As Date
    Get
      Return _SelectedDate
    End Get
    Set(ByVal value As Date)
      _SelectedDate = value
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets the first hour of the day that the TimeSheet must display.
  ''' </summary>
  Public Property StartTime() As Integer
    Get
      Return _StartTime
    End Get
    Set(ByVal value As Integer)
      _StartTime = value
    End Set
  End Property

  ''' <summary>
  ''' Gets or sets the last hour of the day that the TimeSheet must display.
  ''' </summary>
  Public Property EndTime() As Integer
    Get
      Return _EndTime
    End Get
    Set(ByVal value As Integer)
      _EndTime = value
    End Set
  End Property

  ''' <summary>
  ''' Iterates over the DataTables in the _DataSource DataSet, adding rows for each BookingObject and Appointments.
  ''' </summary>
  Public Overrides Sub DataBind()
    ' Make sure we have a valid data source
    If _DataSource IsNot Nothing Then
      If Not _SelectedDate = DateTime.MinValue Then

        ' Create a DataRow for the BookingObjects and for the Appointments
        Dim myBookingObjectRow As DataRow
        Dim myAppointmentRow As DataRow

        Dim myTableRow As TableRow
        Dim myTableCell As TableCell

        ' First, create a new TableRow (for the <asp:Table> defined in the .aspx file) that holds  the column headings.
        myTableRow = New TableRow()
        myTableCell = New TableCell()

        ' Set the name of the first cell to the friendly name of the booking object
        ' and make its font bold
        myTableCell.Text = AppConfiguration.BookingObjectNameSingular
        myTableCell.Style.Add("font-weight", "bold")

        ' Set the width of the cell and add it to the row.    
        myTableCell.Width = New Unit(200)
        myTableRow.Cells.Add(myTableCell)

        ' Add a column header with the hour for each hour between start and end time,
        ' add each cell to the row and finally add the row to the table.
        For i As Integer = _StartTime To _EndTime
          myTableCell = New TableCell
          myTableCell.Text = i.ToString()
          myTableRow.Cells.Add(myTableCell)
        Next
        TimeSheetTable.Rows.Add(myTableRow)

        ' Next, loop through the first dataset and add a row for each BookingObject
        For Each myBookingObjectRow In _DataSource.Tables("BookingObject").Rows
          myTableRow = New TableRow()
          myTableCell = New TableCell()
          myTableCell.Text = Convert.ToString(myBookingObjectRow("Title"))
          myTableCell.Wrap = False
          myTableRow.Cells.Add(myTableCell)

          ' Then loop through each of the appointments for this BookingObject (using myBookingObjectRow.GetChildRows) 
          ' and see if the current hour (defined by i) is available or not.
          For i As Integer = _StartTime To _EndTime
            myTableCell = New TableCell()
            ' Assume the time is available and add a HyperLink to the cell.
            ' The Hyperlink is removed when the time is not available.
            Dim myHyperLink As New HyperLink()
            myHyperLink.NavigateUrl = String.Format( _
                "~/CreateAppointment.aspx?" & _
                 "BookingObjectId={0}&SelectedDate={1}&StartTime={2}", _
                 Convert.ToString(myBookingObjectRow("Id")), _
                 Server.UrlEncode(_SelectedDate.ToString()), i.ToString())
            myHyperLink.Text = "Book"
            myTableCell.Controls.Add(myHyperLink)
            myTableCell.CssClass = "TimesheetCellFree"
            If i >= Convert.ToDateTime(myBookingObjectRow("StartTime")).Hour _
                  And i <= Convert.ToDateTime(myBookingObjectRow("EndTime")).Hour _
                  And Convert.ToInt32(myBookingObjectRow("AvailableOnSelectedDay")) > 0 Then
              For Each myAppointmentRow In _
                  myBookingObjectRow.GetChildRows("BookingObjectAppointment")
                Dim currentDateAndTime As DateTime = _SelectedDate.Date.AddHours(i)
                Dim startDate As DateTime = _
                      Convert.ToDateTime(myAppointmentRow("StartDate"))
                Dim endDate As DateTime = _
                      Convert.ToDateTime(myAppointmentRow("EndDate"))

                If currentDateAndTime >= startDate And currentDateAndTime < endDate Then
                  myTableCell.CssClass = "TimesheetCellBusy"
                  myTableCell.Controls.Clear()
                  myTableCell.Text = "&nbsp;"
                  Exit For
                End If
              Next
            Else
              myTableCell.CssClass = "TimesheetCellBusy"
              myTableCell.Controls.Clear()
              myTableCell.Text = "&nbsp;"
            End If
            myTableRow.Cells.Add(myTableCell)
          Next
          TimeSheetTable.Controls.Add(myTableRow)
        Next
        ' Next, add a row with the legenda
        ' First, calculate the col span
        Dim numCols As Integer = _EndTime - _StartTime + 2

        ' Create an empty row and add it to the table
        myTableRow = New TableRow()
        myTableCell = New TableCell()
        myTableCell.ColumnSpan = numCols
        myTableCell.Text = "&nbsp;"
        myTableRow.Cells.Add(myTableCell)
        TimeSheetTable.Rows.Add(myTableRow)

        ' Next, create a new row and add an empty cell
        myTableRow = New TableRow()
        myTableCell = New TableCell()
        myTableCell.Text = "&nbsp;"
        myTableRow.Cells.Add(myTableCell)

        ' Next, add a legend to the table
        ' We'll be using cell 2, 3, 4 and 5 (with indices of 1, 2, 3, 4) for the legend details
        myTableCell = New TableCell()
        myTableCell.Text = "&nbsp;"
        myTableCell.CssClass = "TimesheetCellBusy"
        myTableRow.Cells.Add(myTableCell)

        myTableCell = New TableCell()
        myTableCell.Text = "Busy"
        myTableRow.Cells.Add(myTableCell)

        myTableCell = New TableCell()
        myTableCell.Text = "&nbsp;"
        myTableCell.CssClass = "TimesheetCellFree"
        myTableRow.Cells.Add(myTableCell)

        myTableCell = New TableCell()
        myTableCell.ColumnSpan = 2
        myTableCell.Text = "Available"
        myTableRow.Cells.Add(myTableCell)

        ' We used up 6 table cells for the legend. Now, add one cell with
        ' the remainder of the columns:
        myTableCell = New TableCell()
        myTableCell.ColumnSpan = numCols - 6
        myTableCell.Text = "&nbsp;"
        myTableRow.Cells.Add(myTableCell)

        TimeSheetTable.Rows.Add(myTableRow)

      Else
        Throw New ArgumentException("Cannot call DataBind without a valid SelectedDate.")
      End If
    End If
  End Sub

End Class
