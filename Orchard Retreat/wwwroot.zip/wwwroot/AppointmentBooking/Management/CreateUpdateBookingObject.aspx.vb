' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Partial Class Management_CreateUpdateBookingObject
  Inherits System.Web.UI.Page

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    If Not Page.IsPostBack Then
      If Request.QueryString.Get("Id") IsNot Nothing Then
        ' Load an existing BookingObject from the database.
        Dim myBookingObject As BookingObject = BookingObjectManager.GetBookingObject(Convert.ToInt32(Request.QueryString.Get("Id")))
        txtTitle.Text = myBookingObject.Title
        lstStartTime.SelectedHour = myBookingObject.StartTime
        lstEndTime.SelectedHour = myBookingObject.EndTime

        chkLstWorkingdays.DataBind()
        ' Check each available working day in the CheckBoxList 
        If Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Sunday) Then
          chkLstWorkingdays.Items.FindByValue("1").Selected = True
        End If
        If Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Monday) Then
          chkLstWorkingdays.Items.FindByValue("2").Selected = True
        End If
        If Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Tuesday) Then
          chkLstWorkingdays.Items.FindByValue("3").Selected = True
        End If
        If Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Wednesday) Then
          chkLstWorkingdays.Items.FindByValue("4").Selected = True
        End If
        If Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Thursday) Then
          chkLstWorkingdays.Items.FindByValue("5").Selected = True
        End If
        If Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Friday) Then
          chkLstWorkingdays.Items.FindByValue("6").Selected = True
        End If
        If Convert.ToBoolean(myBookingObject.AvailableOnWeekdays And Weekdays.Saturday) Then
          chkLstWorkingdays.Items.FindByValue("7").Selected = True
        End If
        litHeading.Text = "Edit " & myBookingObject.Title
      Else
        litHeading.Text = "Create new " & AppConfiguration.BookingObjectNameSingular
      End If
    End If
  End Sub

  Protected Sub UpdateButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateButton.Click
    Page.Validate()
    If Page.IsValid Then

      Dim myBookingObject As New BookingObject()
      If Request.QueryString.Get("Id") IsNot Nothing Then
        myBookingObject.Id = Convert.ToInt32(Request.QueryString.Get("Id"))
      End If
      myBookingObject.Title = txtTitle.Text
      myBookingObject.StartTime = lstStartTime.SelectedHour
      myBookingObject.EndTime = lstEndTime.SelectedHour

      For Each myItem As ListItem In chkLstWorkingdays.Items
        If myItem.Selected = True Then
          Select Case Convert.ToInt32(myItem.Value)
            Case 1 ' Sunday
              myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Sunday
            Case 2
              myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Monday
            Case 3
              myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Tuesday
            Case 4
              myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Wednesday
            Case 5
              myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Thursday
            Case 6
              myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Friday
            Case 7
              myBookingObject.AvailableOnWeekdays = myBookingObject.AvailableOnWeekdays Or Weekdays.Saturday
          End Select
        End If
      Next

      BookingObjectManager.SaveBookingObject(myBookingObject)

      EndEditing()
    End If
  End Sub

  Protected Sub UpdateCancelButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelButton.Click
    EndEditing()
  End Sub

  Private Sub EndEditing()
    Response.Redirect("BookingObjects.aspx")
  End Sub
End Class
