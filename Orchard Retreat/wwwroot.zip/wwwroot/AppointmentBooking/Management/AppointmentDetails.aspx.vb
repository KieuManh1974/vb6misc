' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Partial Class Management_AppointmentDetails
  Inherits System.Web.UI.Page

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    If Request.QueryString.Get("Id") IsNot Nothing Then
      Try
        Dim id As Integer = Convert.ToInt32(Request.QueryString.Get("Id"))
        Dim myAppointment As Appointment = AppointmentManager.GetAppointment(id)
        If myAppointment IsNot Nothing Then
          lblAppointmentDate.Text = myAppointment.StartDate.ToShortDateString()
          lblFrom.Text = myAppointment.StartDate.TimeOfDay.ToString()
          lblUntil.Text = myAppointment.EndDate.TimeOfDay.ToString()
          lblCustomer.Text = String.Format(myAppointment.UserName & " (<a href=""mailto:{0}"">{0}</a>)", myAppointment.UserEmailAddress)
          lblComments.Text = myAppointment.Comments
        End If
      Catch
        Throw
      End Try
    Else
      Response.Redirect("~/")
    End If
  End Sub
End Class
