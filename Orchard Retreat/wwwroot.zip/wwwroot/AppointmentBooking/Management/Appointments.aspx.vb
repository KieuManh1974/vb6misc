' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Imports System.Data

Partial Class Management_Appointments
    Inherits System.Web.UI.Page

  Private Sub LoadData()
    Dim dsAppointments As DataSet
    If Not calAppointmentDate.SelectedDate = DateTime.MinValue Then
      dsAppointments = AppointmentManager.GetAppointmentList(calAppointmentDate.SelectedDate)
      repBookingObjects.DataSource = dsAppointments.Tables("BookingObject").DefaultView
      repBookingObjects.DataBind()
      If repBookingObjects.Items.Count = 0 Then
        lblNoRecords.Visible = True
      End If
    End If
  End Sub

  Protected Sub repBookingObjects_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles repBookingObjects.ItemDataBound
    Dim item As RepeaterItem = e.Item
    If item.ItemType = ListItemType.Item Or item.ItemType = ListItemType.AlternatingItem Then
      Dim repAppointments As Repeater = item.FindControl("repAppointments")
      Dim myDataRowView As DataRowView = CType(item.DataItem, DataRowView)
      repAppointments.DataSource = myDataRowView.CreateChildView("BookingObjectAppointment")
      repAppointments.DataBind()
    End If
  End Sub

  Protected Sub calAppointmentDate_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles calAppointmentDate.SelectionChanged
    lblSelectedDate.Visible = True
    lblSelectedDate.Text = "You selected: <strong>" & calAppointmentDate.SelectedDate.ToShortDateString() & "</strong>"
    lblInstructions.Text = "&nbsp;&nbsp;&nbsp;Click the calendar again to select a different date:"
    LoadData()
  End Sub

End Class
