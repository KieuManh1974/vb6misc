' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Imports System.Web.Configuration

Partial Class Management_Configuration
  Inherits System.Web.UI.Page

  Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
    Dim myConfig As System.Configuration.Configuration = _
          WebConfigurationManager.OpenWebConfiguration("~/")

    Dim myElement As KeyValueConfigurationElement = Nothing

    myElement = myConfig.AppSettings.Settings("BookingObjectNameSingular")
    If Not myElement Is Nothing Then
      myElement.Value = txtBookingObjectNameSingular.Text
    End If

    myElement = myConfig.AppSettings.Settings("BookingObjectNamePlural")
    If Not myElement Is Nothing Then
      myElement.Value = txtBookingObjectNamePlural.Text
    End If

    myElement = myConfig.AppSettings.Settings("RequireCommentsInRequest")
    If Not myElement Is Nothing Then
      myElement.Value = chkRequireCommentsInRequest.Checked.ToString()
    End If

    myElement = myConfig.AppSettings.Settings("FirstAvailableWorkingHour")
    If Not myElement Is Nothing Then
      myElement.Value = hpStartTime.SelectedHour.ToString()
    End If

    myElement = myConfig.AppSettings.Settings("LastAvailableWorkingHour")
    If Not myElement Is Nothing Then
      myElement.Value = hpEndTime.SelectedHour.ToString()
    End If

    Try
      myConfig.Save()
      Response.Redirect("Default.aspx")
    Catch ex As Exception
      litErrorMessage.Visible = True
    End Try
  End Sub

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    If Not Page.IsPostBack Then
      btnSave.OnClientClick = "return confirm('Saving these settings " & _
        "might result in a loss of data for currently active users. Are you sure " & _
        "you want to continue?')"
    End If
  End Sub
End Class
