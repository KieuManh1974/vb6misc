' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Partial Class SignUp
  Inherits System.Web.UI.Page

  Protected Sub CreateUserWizard1_SendingMail(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.MailMessageEventArgs) Handles CreateUserWizard1.SendingMail
    ' Customize the mail body by replacing the placeholders in the static mail body file with actual values.
    e.Message.Body = e.Message.Body.Replace("##Id##", Membership.GetUser(CreateUserWizard1.UserName).ProviderUserKey.ToString())
    e.Message.Body = e.Message.Body.Replace("##UserName##", CreateUserWizard1.UserName)

    Dim applicationFolder As String = Request.ServerVariables.Get("SCRIPT_NAME").Substring(0, Request.ServerVariables.Get("SCRIPT_NAME").LastIndexOf("/"))
    e.Message.Body = e.Message.Body.Replace("##FullRootUrl##", Helpers.GetCurrentServerRoot & applicationFolder)
  End Sub

  Protected Sub CreateUserWizard1_ContinueButtonClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles CreateUserWizard1.ContinueButtonClick
    Response.Redirect("~/")
  End Sub
End Class
