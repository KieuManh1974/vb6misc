' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Partial Class ConfirmAccount
  Inherits System.Web.UI.Page

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    Try
      ' Get the user's Guid from the Query String.
      Dim userId As Guid = New Guid(Request.QueryString.Get("Id"))

      Dim myUser As MembershipUser = Membership.GetUser(userId)
      If myUser IsNot Nothing Then
        ' The user was found in the system, so we can activate the account.
        myUser.IsApproved = True
        Membership.UpdateUser(myUser)
        plcSuccess.Visible = True
      Else
        lblErrorMessage.Visible = True
      End If
    Catch ex As Exception
      lblErrorMessage.Visible = True
    End Try
  End Sub
End Class
