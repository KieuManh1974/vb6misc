' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Partial Class CheckAvailability
  Inherits System.Web.UI.Page

  Private Sub LoadData()
    If Not calAppointmentDate.SelectedDate = DateTime.MinValue Then
      ' A validate date was chosen on the calendar. Get the TimeSheet and bind it to the TimeSheet control.
      TimeSheet1.DataSource = _
               AppointmentManager.GetTimeSheet(calAppointmentDate.SelectedDate)
      TimeSheet1.SelectedDate = calAppointmentDate.SelectedDate
      TimeSheet1.DataBind()
    End If
  End Sub

  Protected Sub calAppointmentDate_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles calAppointmentDate.SelectionChanged
    If calAppointmentDate.SelectedDate.CompareTo(DateTime.Now.Date) < 0 Then
      ' An invalid date was chosen; display the error message and the calendar again.
      valSelectedDate.IsValid = False
      divCalendar.Style.Item("display") = "block"
    Else
      ' Hide the calendar
      divCalendar.Style.Item("display") = "none"
      lblSelectedDate.Visible = True
      lblSelectedDate.Text = "You selected: <strong>" & calAppointmentDate.SelectedDate.ToShortDateString() & "</strong>"
      lblInstructions.Text = "&nbsp;&nbsp;&nbsp;Click the calendar again to select a different date:"
      LoadData()
    End If
  End Sub

  Protected Sub calAppointmentDate_VisibleMonthChanged(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.MonthChangedEventArgs) Handles calAppointmentDate.VisibleMonthChanged
    ' The user switched to another month; show the calendar again so they can select a day.
    divCalendar.Style.Item("display") = "block"
  End Sub

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    ' At initial load, hide the calendar with a CSS property.
    divCalendar.Style.Item("display") = "none"
  End Sub
End Class
