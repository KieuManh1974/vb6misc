' This code is from the book "ASP.NET 2.0 Instant Results" by
' Imar Spaanjaars, Paul Wilton and Shawn Livermore, published by Wrox. 
' Copyright 2006 by Wiley Publishing Inc.
' Information about this book is available at www.wrox.com. 
' Visit p2p.wrox.com to discuss this code in the Wrox forums.

Partial Class CreateAppointment
  Inherits System.Web.UI.Page

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    ' Change the Page Title
    Me.Title = AppConfiguration.BookingObjectNameSingular & " Selection Wizard"
    If Not Page.IsPostBack Then
      ' Always start at the first page of the wizard
      wizAppointment.ActiveStepIndex = 0
      If Request.QueryString.Get("BookingObjectId") IsNot Nothing Then
        ' If params have been passed to this page, preselect the controls in the wizard pages.
        lstBookingObject.SelectedIndex = -1
        lstBookingObject.DataBind()
        lstBookingObject.Items.FindByValue(Request.QueryString.Get("BookingObjectId")).Selected = True
        calStartDate.SelectedDate = Convert.ToDateTime(Request.QueryString.Get("SelectedDate"))
        hpTime.SelectedHour = Convert.ToInt32(Request.QueryString.Get("StartTime"))
        ' Move to the step with time and duration
        wizAppointment.ActiveStepIndex = 3
      End If
    End If
    ' Set the title of the link with the Booking Object
    wizAppointment.WizardSteps(1).Title = "Select a " & AppConfiguration.BookingObjectNameSingular
    reqBookingObject.ErrorMessage = "Please select a " & AppConfiguration.BookingObjectNameSingular
  End Sub

  Protected Sub wizAppointment_ActiveStepChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles wizAppointment.ActiveStepChanged
    Select Case wizAppointment.ActiveStepIndex
      Case 4
        ' Comments step. See if we need to enable the RequiredFieldValidator for the comments.
        reqComments.Enabled = AppConfiguration.RequireCommentsInRequest
      Case 5
        ' Final step, validate all pages.
        If ValidateAllSteps() Then
          Dim startDate As DateTime = calStartDate.SelectedDate.AddHours(hpTime.SelectedHour)
          Dim endDate As DateTime = startDate.AddHours(Convert.ToInt32(lstDuration.SelectedValue))
          lblBookingObject.Text = lstBookingObject.SelectedItem.Text
          lblStartTime.Text = startDate.ToString()
          lblEndTime.Text = endDate.ToString()
          lstDuration.Text = lstDuration.SelectedValue
          lblComments.Text = txtComments.Text
        End If
    End Select
  End Sub

  Protected Sub wizAppointment_NextButtonClick(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.WizardNavigationEventArgs) Handles wizAppointment.NextButtonClick
    ' Validate individual steps.
    ' Note that we don't have to validate step 3, as by default the first item in the two
    ' DropDownList controls will be selected.
    Select Case e.CurrentStepIndex
      Case 1
        If Not ValidateStep(1) Then
          e.Cancel = True
        End If
      Case 2
        If Not ValidateStep(2) Then
          e.Cancel = True
        End If
      Case 4
        If Not ValidateStep(4) Then
          e.Cancel = True
        End If
    End Select
  End Sub

  Protected Sub wizAppointment_FinishButtonClick(ByVal sender As Object, _
          ByVal e As System.Web.UI.WebControls.WizardNavigationEventArgs) Handles wizAppointment.FinishButtonClick
    Page.Validate()
    If Page.IsValid Then

      If ValidateAllSteps() Then
        ' All steps valid. Create a new Appointment, check if it can be made and then finalize it.
        wizAppointment.Visible = False

        Dim myAppointment As New Appointment()
        myAppointment.StartDate = _
            calStartDate.SelectedDate.AddHours(hpTime.SelectedHour)
        myAppointment.EndDate = _
            myAppointment.StartDate.AddHours(Convert.ToInt32( _
                lstDuration.SelectedValue))
        myAppointment.BookingObjectId = _
            Convert.ToInt32(lstBookingObject.SelectedValue)
        myAppointment.Comments = _
            Server.HtmlEncode(txtComments.Text)
        Dim myUser As MembershipUser = Membership.GetUser()
        myAppointment.UserName = myUser.UserName
        myAppointment.UserEmailAddress = myUser.Email

        If AppointmentManager.CheckAppointment(myAppointment) Then
          ' Appointment can be made, so go ahead and finalize it
          AppointmentManager.CreateAppointment(myAppointment)
          MultiView1.ActiveViewIndex = 0
        Else
          ' Tell the user the appointment couldn't be made.
          MultiView1.ActiveViewIndex = 1
        End If
      End If
    End If
  End Sub

  Protected Sub calStartDate_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles calStartDate.SelectionChanged
    ' Validate the requested date and update UI.
    If Not IsStartDateValid() Then
      valStartDate2.IsValid = False
      litSelectedDate.Text = ""
    Else
      litSelectedDate.Text = String.Format("Selected date: {0}/{1}/{2}", calStartDate.SelectedDate.Month, calStartDate.SelectedDate.Day, calStartDate.SelectedDate.Year)
    End If
  End Sub

  Protected Sub lnkTryAgain_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkTryAgain.Click
    ' Show the wizard again, at step 2 (with an index of 1)
    wizAppointment.Visible = True
    wizAppointment.ActiveStepIndex = 1
    MultiView1.ActiveViewIndex = -1
  End Sub

#Region "Validaton Methods"

  Private Function IsStartDateValid() As Boolean
    ' Check if the appointment is in the past
    If calStartDate.SelectedDate.CompareTo(DateTime.Now.Date) < 0 Then
      Return False
    Else
      Return True
    End If
  End Function

  Private Function ValidateAllSteps() As Boolean
    Return ValidateStep(1) AndAlso ValidateStep(2) AndAlso ValidateStep(4)
  End Function

  Private Function ValidateStep(ByVal stepIndex As Integer) As Boolean
    Select Case stepIndex
      Case 1
        ' Step 2 (with an index of 1)
        If lstBookingObject.SelectedItem Is Nothing Then
          reqBookingObject.IsValid = False
          wizAppointment.ActiveStepIndex = 1
          Return False
        End If
      Case 2
        ' Step 3 (with an index of 2)
        If calStartDate.SelectedDate = DateTime.MinValue Then
          valStartDate1.IsValid = False
          wizAppointment.ActiveStepIndex = 2
          Return False
        Else
          If calStartDate.SelectedDate.CompareTo(DateTime.Now.Date) < 0 Then
            valStartDate2.IsValid = False
            wizAppointment.ActiveStepIndex = 2
            Return False
          End If
        End If
      Case 4
        ' Step 5 (with an index of 4)
        If AppConfiguration.RequireCommentsInRequest AndAlso _
              txtComments.Text.Length = 0 Then
          reqComments.IsValid = False
          wizAppointment.ActiveStepIndex = 4
          Return False
        End If
    End Select
    Return True
  End Function
#End Region

End Class
