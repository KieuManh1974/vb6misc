using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace rk_plastering
{
    public partial class masterP : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string page=Request.RawUrl.Substring(1).Replace(".aspx",string.Empty);
            
            HtmlGenericControl activeMenu = null;

            activeMenu = (HtmlGenericControl) FindControl("mnu_" + page);

            activeMenu.Attributes.Add("class", "active");

            if (activeMenu.HasControls()) //remove anchor element
            {
                activeMenu.InnerHtml = page;
            }
            
        }

    }
}
