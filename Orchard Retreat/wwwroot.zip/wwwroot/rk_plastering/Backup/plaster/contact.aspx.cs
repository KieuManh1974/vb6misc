using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Mail;
using System.Web.Configuration;

namespace rk_plastering
{
    public partial class contact : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //DecryptString();
            //EncryptString();
        }

        protected void btnSubmitEnquiry_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string phone = txtPhone.Text.Trim();
            string details = txtEnquiry.Text.Trim();

            if (name == string.Empty)
            {
                lblInfo.Text = "Please enter your name";
                return;
            }
            if (phone == string.Empty)
            {
                lblInfo.Text = "Please enter your phone number";
                return;
            }
            if (details == string.Empty)
            {
                lblInfo.Text = "Please enter details of enquiry";
                return;
            }

            string msg = name + Environment.NewLine +
                            phone + Environment.NewLine +
                            details;
            //send email first

            try
            {
                MailMessage mail = new MailMessage();
                mail.To = ConfigurationManager.AppSettings.Get(rk_plastering.Globs.MAIL_TO);
                mail.From = ConfigurationManager.AppSettings.Get(rk_plastering.Globs.MAIL_FROM);
                mail.Cc = ConfigurationManager.AppSettings.Get(rk_plastering.Globs.MAIL_CC); //send copy to rog
                mail.BodyFormat = MailFormat.Text;

                mail.Subject = "Someone used the website!";
                mail.Body = msg;
                SmtpMail.SmtpServer = "localhost";
                SmtpMail.Send(mail);
            }
            catch
            {
                //mail failed for some reason
            }


            string smsUser = ConfigurationManager.AppSettings.Get(rk_plastering.Globs.SMS_USERNAME);
            string smsPword = ConfigurationManager.AppSettings.Get(rk_plastering.Globs.SMS_PASSWORD);

#if DEBUG
            string olMobile = ConfigurationManager.AppSettings.Get(rk_plastering.Globs.ROG_MOBILE);
#else
			string olMobile = ConfigurationSettings.AppSettings.Get(rk_plastering.Globs.ROB_MOBILE);
#endif
            string paras = "username=" + smsUser + "&password=" + smsPword + "&to_num=" + olMobile + "&message=" + msg + "&flash=0";

            //all good - send text to olly
            HTTP_Post postSMS = new HTTP_Post(ConfigurationManager.AppSettings.Get(rk_plastering.Globs.SMS2EMAIL), paras);

            string response;

            if (!postSMS.Post(out response))
            {
                lblInfo.Text = "Message failed";
            }
            else
            {
                //response codes on page http://www.sms2email.com/site/developerinfo2.php
                if (response.Trim().ToUpper() == "AQSMS-OK")
                    lblInfo.Text = "Message sent";
            }
        }
        private void EncryptString()
        {
            Configuration config = WebConfigurationManager.OpenWebConfiguration(Request.ApplicationPath);

            ConfigurationSection section = config.GetSection("appSettings");

            if (!section.SectionInformation.IsProtected)
            {
                section.SectionInformation.ProtectSection("RsaProtectedConfigurationProvider");
                config.Save();
            }
        }
        private void DecryptString()
        {
            Configuration config = WebConfigurationManager.OpenWebConfiguration(Request.ApplicationPath);

            ConfigurationSection section = config.GetSection("appSettings");

            if (section.SectionInformation.IsProtected)
            {
                section.SectionInformation.UnprotectSection();
                config.Save();
            }
        }
    }
}
