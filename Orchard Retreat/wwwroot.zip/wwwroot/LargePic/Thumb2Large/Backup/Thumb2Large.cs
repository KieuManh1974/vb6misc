using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
[assembly : TagPrefix("RBGP.WebControls", "rbgp")]

namespace RBGP.WebControls
{
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:Thumb2LargeControl runat=server></{0}:Thumb2LargeControl>")]
    public class Thumb2LargeControl : System.Web.UI.WebControls.HyperLink 
    {

        private string _sTitle;
        private string _sSection;

        protected override void Render(HtmlTextWriter writer)
        {

            HyperLink link = this;

            int iLastSegment = HttpContext.Current.Request.Url.Segments.GetUpperBound(0);
            string sLastSegment = HttpContext.Current.Request.Url.Segments.GetValue(iLastSegment).ToString();

            string path = HttpContext.Current.Request.Url.AbsoluteUri.Replace(sLastSegment, string.Empty);

            const string URL = "http://www.codeup.co.uk/large_picture.html?";
            /*
            <a href="http://www.codeup.norrisandson.co.uk/large_picture.html?title=Front of studio&image=http://orchardretreat.norrisandson.co.uk/images/houseFront_w600.jpg&url=http://orchardretreat.norrisandson.co.uk/home.aspx&section=s0">
                <img src="images/thumbs/houseFront_w600.jpg" alt="front of studio" style="float:left; margin-right:15px" />
            </a>
            <a href="http://www.codeup.norrisandson.co.uk/large_picture.html?title=Front of studio&image=http://localhost/OrchardRetreat/images/housefront_w600.jpg&url=http://localhost/OrchardRetreat/Home.aspx&section=s0" target="_blank"<img src="http://localhost/OrchardRetreat/images/thumbs/housefront_w600.jpg" alt="Front Of Studio" style="float:left; margin-right:15px"/></a>
            */

            string href = URL + "title=" + _sTitle + "&image=" + path + link.ImageUrl + "&url=" + HttpContext.Current.Request.Url.AbsoluteUri + "%23s" + _sSection;

            writer.Write("<a");
            
            writer.WriteAttribute("href", href);
            
            writer.Write("><img");

            writer.WriteAttribute("src", path + link.ImageUrl.Replace("images","images/thumbs"));

            writer.WriteAttribute("alt", ToTitleCase(_sTitle));
            
            foreach (string key in link.Attributes.Keys)
                writer.WriteAttribute(key, link.Attributes[key]);

            writer.Write("/>");

            RenderContents(writer);
            writer.Write("</a>");
        }

        protected override void RenderContents(HtmlTextWriter output)
        {
            output.Write(Text);
        }

        public string Title
        {
            set
            {
                _sTitle = value;
            }
        }

        public string Section
        {
            set
            {
                _sSection = value;
            }
        }

        private static string ToTitleCase(string mText)
        {
            string rText = "";
            try
            {
                System.Globalization.CultureInfo cultureInfo =
    System.Threading.Thread.CurrentThread.CurrentCulture;
                System.Globalization.TextInfo TextInfo = cultureInfo.TextInfo;
                rText = TextInfo.ToTitleCase(mText);
            }
            catch
            {
                rText = mText;
            }
            return rText;
        }

     
    }
}
