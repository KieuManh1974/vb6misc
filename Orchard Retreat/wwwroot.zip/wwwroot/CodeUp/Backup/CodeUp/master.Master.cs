using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace CodeUp
{
    public partial class master : System.Web.UI.MasterPage
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            string page = Request.RawUrl.Substring(1).Replace(".aspx", string.Empty);

            extraLink.Attributes.Add("href", page + ".css");

            Console.WriteLine(page + ".css");
        }

        public void CurrentMenu(MenuItems mItem)
        {
            string name = Enum.GetName(typeof(CodeUp.MenuItems), mItem);

            HtmlTableCell cell = null;

            /*
            switch(mItem)
            {
                case MenuItems.Home:
                    cell = menu_Home;
                    break;
                case MenuItems.Portfolio:
                    cell = menu_Portfolio;
                    break;
                case MenuItems.Contact:
                    cell = menu_Contact;
                    break;
                default:
                    break;
            }*/
            
//            cell.Attributes.Add("class","currentMenu");
            
        }
    }
}
