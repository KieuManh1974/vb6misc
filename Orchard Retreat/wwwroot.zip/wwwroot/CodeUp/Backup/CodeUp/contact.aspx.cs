using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Mail;

namespace CodeUp
{
    public partial class contact : System.Web.UI.Page
    {
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
			    string msg = "Codeup mail:" + Environment.NewLine +
							txtUser.Text + Environment.NewLine + 
							txtEmail.Text + Environment.NewLine +
                            txtPhone.Text + Environment.NewLine + 
							txtEnquiry.Text;
                MailMessage mail = new MailMessage();
                mail.To = "codeup@googlemail.com";
                mail.From = "website@codeup.co.uk";
                mail.Cc = "guille.phillips@googlemail.com; r_butler_999@yahoo.co.uk"; //send copy to guill & rog
                mail.BodyFormat = MailFormat.Text;

                mail.Subject = "CodeUp query";
                mail.Body = msg;
                SmtpMail.SmtpServer = "localhost";
                SmtpMail.Send(mail);
            }
            catch
            {
                //mail failed for some reason
            }
        }
    }
}
