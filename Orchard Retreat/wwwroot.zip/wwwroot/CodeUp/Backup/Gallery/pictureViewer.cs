using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

[assembly: TagPrefix("RBGP.WebControls", "rbgp")]

namespace RBGP.WebControls
{
    [ToolboxData("<{0}:Gallery runat=server></{0}:Gallery>")]
    public class Gallery : DataList
    {
        int _iMaxHeight;
        int _iMaxWidth;
        string _sImgDir;

        public string ImgDirectory
        {
            set
            {
                _sImgDir = value;
            }
            get
            {
                return Page.Server.MapPath(_sImgDir);
            }
        }

        public int MaxHeight
        {
            set { _iMaxHeight = value; }
        }
        public int MaxWidth
        {
            set { _iMaxWidth = value; }
        }

        private void LoadImages()
        {
            ArrayList pics = new ArrayList();
            double imgHeight;
            double imgWidth;

            List<string> fileExtensionsForPics = new List<string>();
            fileExtensionsForPics.Add("*.jpg");
            fileExtensionsForPics.Add("*.jpeg");
            fileExtensionsForPics.Add("*.bmp");

            foreach (string pattern in fileExtensionsForPics)
            {
                foreach (string s in Directory.GetFiles(ImgDirectory, pattern))
                {
                    System.Drawing.Image img = System.Drawing.Image.FromFile(s);

                    string details = string.Empty;
                    string fileName = Path.GetFileName(s);
                    string fileNameNoExtension = Path.GetFileNameWithoutExtension(s);

                    //url stored in the "title" attribute (right click on file
                    //from explorer to see this
                    //adapted from http://www.codeproject.com/KB/shell/shellid3tagreader.aspx
                    Shell32.ShellClass shellClass = new Shell32.ShellClass();
                    Shell32.Folder shellFolder = shellClass.NameSpace(Path.GetDirectoryName(s));
                    Shell32.FolderItem shellFolderItem = shellFolder.ParseName(fileName);

                    details += shellFolder.GetDetailsOf(shellFolderItem, 10);

                    imgHeight = img.Height;
                    imgWidth = img.Width;

                    double maxWidth = Convert.ToDouble(_iMaxWidth);
                    double maxHeight = Convert.ToDouble(_iMaxHeight);

                    if (imgHeight > maxHeight || imgWidth > maxWidth)
                    {
                        double deltaWidth = imgWidth - maxWidth;
                        double deltaHeight = imgHeight - maxHeight;
                        double scaleFactor;

                        if (deltaHeight > deltaWidth)
                        //Scale by the height
                        { scaleFactor = maxHeight / imgHeight; }
                        else
                        //Scale by the Width
                        { scaleFactor = maxWidth / imgWidth; }

                        imgWidth = (int)((double)imgWidth * scaleFactor);
                        imgHeight = (int)((double)imgHeight * scaleFactor);
                    }

                    string html = @"<a target=""_blank"" href=""" + details + @""">" +
                        @"<img alt=""" + fileNameNoExtension + @""" style=""height:" + imgHeight.ToString("0") + "px; width:" + imgWidth.ToString("0") + @"px; margin:3px;"" src=""" + _sImgDir + fileName + @""">" +
                        @"</a><br/><span class=""desc"">" + fileNameNoExtension + "</span>";

                    pics.Add(html);

                }
            }

            base.DataSource = pics;
            base.DataBind();
        }

        protected override void RenderContents(HtmlTextWriter output)
        {
            LoadImages();
            base.RenderContents(output);
        }
    }
}
