using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
[assembly: TagPrefix("RBGP.WebControls", "rbgp")]

namespace RBGP.WebControls
{
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:TextShadowControl runat=server></{0}:TextShadowControl>")]
    public class TextShadowControl : System.Web.UI.Control
    {
        private string _sFont; //Font to display in
        private string _sText; //Text to display
        private string _sTextColour; //RRGGBB
        private string _sShadowColour; //#RRGGBB
        private int _iNumberOfShadows;
        private int _iSize;
        private int _iTop;
        private int _iLeft;
        
        public override void RenderControl(HtmlTextWriter writer)
        {
            
            int iDivHeight = _iSize + 4 * _iNumberOfShadows ;

            string style = "font-family:" + _sFont + "; font-size: " + _iSize.ToString() + "px";

            writer.WriteLine(@"<div style=""" + style + @""">");
            writer.WriteLine(@"<div style=""height: " + iDivHeight.ToString() + @"px; overflow:hidden;"">");

            iDivHeight = iDivHeight - 2 * _iNumberOfShadows;

            for (int i = 0; i < _iNumberOfShadows; i++)
            {
                int iTop = -i * iDivHeight - 2*i;

                style = @"style=""height: " + iDivHeight.ToString() + "px; position: relative; top: " + iTop.ToString() + "px; left: " + (i*-1).ToString() + "px; color: " + ((i == _iNumberOfShadows-1) ? _sTextColour : _sShadowColour) + @";""";
                writer.WriteLine("<div " + style + ">" + _sText + "</div>");
            }

            writer.WriteLine(@"</div></div>");
        }

        /*
        protected override void RenderContents(HtmlTextWriter output)
        {
            output.Write(output);
        }
         * */

        [Description("The actual text to display"), Category("Layout")]
        public string TextToDisplay
        {
            set
            {
                _sText = value;
            }
        }

        [Description("The font to be used"), Category("Layout")]
        public string FontName
        {
            set
            {
                _sFont = value;
            }
        }

        [Description("The colour of the text"), Category("Appearance")] 
        public string TextColour
        {
            set
            {
                _sTextColour = value;
            }
        }

        [Description("The colour of the shadow"), Category("Appearance")] 
        public string ShadowColour
        {
            set
            {
                _sShadowColour = value;
            }
        }

        [Description("The Top position of the shadow"), Category("Appearance")] 
        public int Top
        {
            set
            {
                _iTop = value;
            }
        }

        [Description("The left position of the shadow"), Category("Appearance")] 
        public int Left
        {
            set
            {
                _iLeft = value;
            }
        }

        [Description("The number of shadows"), Category("Appearance")] 
        public int NumberOfShadows
        {
            set
            {
                _iNumberOfShadows = value;
            }
        }

        [Description("The size of the text in pt"), Category("Appearance")] 
        public int SizeOfText
        {
            set
            {
                _iSize = value;
            }
        }
    }
}
