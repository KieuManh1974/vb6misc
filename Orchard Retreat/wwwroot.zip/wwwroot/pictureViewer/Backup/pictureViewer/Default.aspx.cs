using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

namespace pictureViewer
{
    public partial class _Default : System.Web.UI.Page
    {
        const string IMAGE_DIRECTORY = "/images/";

        protected void Page_Load(object sender, EventArgs e)
        {
            ArrayList pics = new ArrayList();
            double imgHeight;
            double imgWidth;

            foreach (string s in Directory.GetFiles(Server.MapPath(IMAGE_DIRECTORY)))
            {
                System.Drawing.Image img = System.Drawing.Image.FromFile(s);

                imgHeight = img.Height;
                imgWidth = img.Width;

                double maxWidth = Convert.ToDouble(ConfigurationManager.AppSettings["PIC_MAX_WIDTH"].ToString());
                double maxHeight = Convert.ToDouble(ConfigurationManager.AppSettings["PIC_MAX_HEIGHT"].ToString());

                if (imgHeight > maxHeight || imgWidth > maxWidth)
                {
                    double deltaWidth = imgWidth - maxWidth;
                    double deltaHeight = imgHeight - maxHeight;
                    double scaleFactor;
                        
                    if (deltaHeight > deltaWidth)
                      //Scale by the height
                        {scaleFactor = maxHeight / imgHeight;}
                    else
                      //Scale by the Width
                        {scaleFactor = maxWidth / imgWidth;}
                   
                    imgWidth = (int) ((double) imgWidth * scaleFactor);
                    imgHeight = (int)((double)imgHeight * scaleFactor);
                }

                string html = @"<a href=""" + IMAGE_DIRECTORY + Path.GetFileName(s) + @""">" +
                    @"<img style=""height:" + imgHeight.ToString("0") + "px; width:" + imgWidth.ToString("0") + @"px; margin:3px;"" src=""" + IMAGE_DIRECTORY + Path.GetFileName(s) + @""">" +
                    "</a>";
             
                pics.Add(html);

            }

            dlPictures.DataSource = pics;
            dlPictures.DataBind();

        }

    }
}
