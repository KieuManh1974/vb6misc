using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.IO;
using System.Data.OleDb;
using System.Threading;

namespace Gateway
{
	/// <summary>
	/// Summary description for Service1.
	/// </summary>

	[WebService(Namespace="http://xmlRequestManager")]
	public class GatewayRequest : System.Web.Services.WebService//, IPingInterface.IPing
	{
		globalVariables m_gv = globalVariables.GLOB_V;
		DataHandler dh = new DataHandler();

		public GatewayRequest()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		[WebMethod(Description="This method simply returns whether the gateway has died")]
		public string Ping()
		{
			/*
			ServerTop.Processor proc = (ServerTop.Processor)Activator.GetObject
				(typeof(ServerTop.Processor), "tcp://" + m_gv.GetMeAWorker + "/ServerRequest");

			try
			{
				return proc.Ping();
			}
			catch (Exception ee)
			{
				return ee.Message;
			}
			*/

			return Boolean.TrueString;
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		
		[WebMethod(Description="This method passes the xmlIn work request to a 'worker' machine, and returns the result")]
		public string FarmWorkerRequest(string xmlIn)
		{
			
			#region get client's ip and save request to db on different thread
			
			//obtain client's IP address (from http://www.thescripts.com/forum/thread532376.html)
			string clientIp;
			
			clientIp=Context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
			if(clientIp==null)
			{
				clientIp=Context.Request.ServerVariables["REMOTE_ADDR"];
			}

			m_gv.RegisterChannel();


			/*
			StopWatch sw1 = new StopWatch();

			sw1.Reset();
			*/
			
			
			DataHandlerWrapper dhw = new DataHandlerWrapper(xmlIn, clientIp, Server.MapPath("/Gateway/data/gateway traffic.mdb") , dh);

			Thread t = new Thread(new ThreadStart(dhw.StoreRequestInDB));
			//dhw.StoreRequestInDB();

			t.Start();
			
			/*
			long time1 = sw1.Peek();

			Console.WriteLine("Time = " + time1/10.0 + " milliseconds.");
			*/
			
			#endregion

			ServerTop.Processor proc = (ServerTop.Processor)Activator.GetObject
				(typeof(ServerTop.Processor), m_gv.GetMeAWorker);

			
			
			 
			bool blAlive=false;
			
			while (!blAlive)

			{
				proc = (ServerTop.Processor)Activator.GetObject
					(typeof(ServerTop.Processor),  m_gv.GetMeAWorker );

				string check = string.Empty;

				try
				{
					check = proc.Ping();
				}
				catch(Exception ee)
				{
					Console.WriteLine (ee.Message);
					//some error, but whatever it is, we know server is dead
				}

				blAlive = (check == System.Boolean.TrueString);
			}
			

			try
			{
				return proc.WorkRequest(xmlIn);
			}
			catch (Exception ex)
			{
				return (ex.Message);
			}
		}

	}
}
