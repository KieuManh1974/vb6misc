using System;
using System.Data.OleDb;
using System.Runtime.CompilerServices;
using System.Data;
using System.Net;

namespace Gateway
{
	/// <summary>
	/// Summary description for dataHandler.
	/// </summary>
	public class DataHandler
	{
		static OleDbConnection mdbConnection;
		static object myLockObject = new object();

		public DataHandler()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public OleDbConnection AccessConnection(string path)
		{
			const string CONNECTION_STRING_SOURCE = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=";

			if (mdbConnection == null)
			{
				mdbConnection = new OleDbConnection(CONNECTION_STRING_SOURCE + path);
			}

			return mdbConnection;
		}

		#region store request in database
		public void StoreRequest(string inXml, string clientIP,string path)
		{
			lock(myLockObject)
			{
				OleDbConnection con = AccessConnection(path);

				try
				{
					if (con.State == ConnectionState.Closed)
					{
						con.Open();
					}

					OleDbCommand oleComm	= new OleDbCommand ("AddRequest",con);
					oleComm.CommandType		= CommandType.StoredProcedure;
					oleComm.CommandTimeout	= 5;

					OleDbParameter pXML = oleComm.Parameters.Add ("paraXmlRequest",OleDbType.LongVarChar);
					pXML.Value = inXml;

					OleDbParameter pClientId = oleComm.Parameters.Add ("paraClientIP",OleDbType.VarChar);
					pClientId.Value = clientIP;

					OleDbParameter pHostName = oleComm.Parameters.Add ("paraHostName",OleDbType.VarChar);
					pHostName.Value = getHost(clientIP);

					oleComm.Connection = con;

					oleComm.ExecuteNonQuery();

				}
				catch (Exception ee)
				{
					throw new ArgumentException(ee.Message);
				}
				finally
				{
					try
					{
						con.Close();
					}
					catch
					{
					}
				}
			}
		}

		/*
		public System.Collections.ArrayList getWorkerMachines(string path)
		{
			lock(myLockObject)
			{
				OleDbConnection con = AccessConnection();

				System.Collections.ArrayList ar = new System.Collections.ArrayList();

				try
				{
					if (con.State == ConnectionState.Closed)
					{
						con.Open();
					}

					OleDbCommand oleComm	= new OleDbCommand ("GetW",con);
					oleComm.CommandType		= CommandType.StoredProcedure;
					oleComm.CommandTimeout	= 5;

					oleComm.Connection = con;

					OleDbDataReader dr = oleComm.ExecuteReader();
				
					while (dr.Read())
					{
						ServerMachinesAndOwners smao = new ServerMachinesAndOwners(dr["Server"].ToString(),dr["Owner"].ToString());
						ar.Add (smao);
					}

					dr.Close();

				}
				catch (Exception ee)
				{
					throw new ArgumentException(ee.Message);
				}
				finally
				{
					try
					{
						con.Close();
					}
					catch
					{
					}
				}

				return ar;
			}
			
		}
		*/
		#endregion

		public string getHost(string ip) 
		{ 
			IPHostEntry IpEntry = Dns.GetHostByAddress(ip); 
			return IpEntry.HostName; 
		} 
	}

	public class DataHandlerWrapper
	{
		private string _inXml;
		private string _clientIP;
		private string _path;
		private DataHandler _dh;

		public DataHandlerWrapper(string inXml, string clientIP,string path, DataHandler dh)
		{
			_inXml = inXml;
			_clientIP = clientIP;
			_path = path;
			_dh = dh;
		}

		public void StoreRequestInDB()
		{
			_dh.StoreRequest(_inXml, _clientIP, _path);
		}
	}

	public class ServerMachinesAndOwners
	{
		string _server;
		string _owner;

		public ServerMachinesAndOwners(string server, string owner)
		{
			_server = server;
			_owner = owner;
		}

		public string Server
		{
			get
			{
				return _server;
			}
		}

		public string Owner
		{
			get
			{
				return _owner;
			}
		}
	}
	
}
