using System;
using System.Threading;
using System.Runtime.Remoting.Channels.Tcp;
using System.Runtime.Remoting.Channels;
using System.Web;
using System.Web.Services;
using System.Collections.Specialized;
using CustomConfigurationSettings;

namespace Gateway
{

	public class globalVariables
	{
		static object sync = new object();
		static globalVariables gv;
		static int m_intWorkerMachine=-1;
		//static System.Collections.ArrayList m_alWorkers;
		static TcpClientChannel channel4;

		public static globalVariables GLOB_V
		{
			get
			{
				lock(sync) //acquire the lock. This code is run by only one thread at a time
				{
					if (gv == null)
					{
						gv = new globalVariables();
					}
					return gv;
				}
			}
		}

		public void RegisterChannel()
		{
			if (channel4 == null)
			{
				//put back in when mark has finished debugging!
				//System.Collections.IDictionary t = new System.Collections.Hashtable();
				//t.Add ("timeout",(uint)15000);
				//channel4 = new TcpClientChannel(t,null);
				channel4 = new TcpClientChannel();
				ChannelServices.RegisterChannel(channel4);
			}
		}


		public string GetMeAWorker
		{
			get
			{
				
				//System.Security.Principal.WindowsImpersonationContext impersonationContext;
				//impersonationContext = 
					//((System.Security.Principal.WindowsIdentity)HttpContext.Current.User.Identity).Impersonate();

				//Insert your code that runs under the security context of the authenticating user here.

				
				NameValueCollection nvc = (NameValueCollection) ConfigurationSettings.GetConfig("appSettings",@"\\gblond002fs1\trgedexport$\xlstart\xlsys\workerMachines.xml");

				//impersonationContext.Undo();
				m_intWorkerMachine++;

				if (m_intWorkerMachine > nvc.Count-1)
				{
					m_intWorkerMachine=0;
				}

				//return "gbws-00150875:4322";

				return nvc[m_intWorkerMachine];

			}
		}
	}

}
