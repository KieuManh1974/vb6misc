using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ContentEditing;


public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        MembershipUser user = null;
        bool _loggedIn = false;

        try
        {
            string guid = Request.QueryString["guid"];

            if (guid != null)
            {
                GetSessionFromDatabase(guid);
                //ClearSessionFromDatabase(guid);
                FormsAuthentication.SetAuthCookie("in", false);
//                Response.Redirect("~" + Request.QueryString["ReturnUrl"]);
                //Response.Redirect("~/RestrictedArea/Members.aspx");
                _loggedIn = true;
            }
        }
        catch { }
        
        LoginButton.Visible = !_loggedIn;
        LogoutButton.Visible = _loggedIn;

    }
    //This method retrieves the session information identified by the parameter
    //  guidIn from the database.
    private void GetSessionFromDatabase(string guidIn)
    {
        //**************************************
        //Enter connection information here

        SqlConnection con = new SqlConnection("Server=plesksql1.ehosting.com;Initial Catalog=members;User Id=codeup;Password=thargoid;Trusted_Connection=False;");

        //**************************************
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;
        con.Open();
        cmd.Connection = con;

        string strSql;

        //Get a DataReader that contains all the Session information
        strSql = "SELECT * FROM ASPSessionState WHERE GUID = '" + guidIn + "'";
        cmd.CommandText = strSql;
        dr = cmd.ExecuteReader();

        //Iterate through the results and store them in the session object
        while (dr.Read())
        {
            Session[dr["SessionKey"].ToString()] = dr["SessionValue"].ToString();
        }

        //Clean up database objects
        dr.Close();
        con.Close();
        cmd.Dispose();
        con.Dispose();
    }


    //This method removes all session information from the database identified by the 
    //  the GUID passed in through the parameter guidIn.
    private void ClearSessionFromDatabase(string guidIn)
    {
        //**************************************
        //Enter connection information here

        SqlConnection con = new SqlConnection("Server=plesksql1.ehosting.com;Initial Catalog=members;User Id=codeup;Password=thargoid;Trusted_Connection=False;");

        //**************************************
        SqlCommand cmd = new SqlCommand();
        con.Open();
        cmd.Connection = con;
        string strSql;

        strSql = "DELETE FROM ASPSessionState WHERE GUID = '" + guidIn + "'";
        cmd.CommandText = strSql;
        cmd.ExecuteNonQuery();

        con.Close();
        cmd.Dispose();
        con.Dispose();
    }
    protected void Login_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/RestrictedArea/Members.aspx");
    }

    protected void Logout_Click(object sender, EventArgs e)
    {
        FormsAuthentication.SignOut();
        ContentEditor.DisableEditingForCurrentSession();
        LogoutButton.Visible = false;
        LoginButton.Visible = true;
    }

    protected void Postback_Click(object sender, EventArgs e)
    {
    }

    protected void Redirect_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Default.aspx");
    }

}
