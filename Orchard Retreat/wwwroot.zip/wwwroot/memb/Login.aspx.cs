using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;



public partial class Login : System.Web.UI.Page
{
    string returnURL = string.Empty;

    protected void Login1_LoginError(object sender, EventArgs e)
    {
        //See if this user exists in the database
        MembershipUser userInfo = Membership.GetUser(Login1.UserName);

        if (userInfo == null)
        //The user entered an invalid username...
        { LoginErrorDetails.Text = "There is no user in the database with the username " + Login1.UserName; }
        else
        {
            //See if the user is locked out or not approved
            if (!userInfo.IsApproved)
                LoginErrorDetails.Text = "Your account has not yet been approved by the site's administrators. Please try again later...";
            else if (userInfo.IsLockedOut)
                LoginErrorDetails.Text = "Your account has been locked out because of a maximum number of incorrect login attempts. You will NOT be able to login until you contact a site administrator and have your account unlocked.";
            else
                //The password was incorrect (don't show anything, the Login control already describes the problem)
                LoginErrorDetails.Text = String.Empty;
        }

    }
    protected void Login1_LoggedIn(object sender, EventArgs e)
    {

        //Add the session information to the database, and redirect to the
        //  ASP implementation of SessionTransfer.
        
        //Response.Redirect("SessionTransfer.asp?dir=2asp&guid=" + guidSave +
          //  "&url=" + Server.UrlEncode(Request.QueryString["url"]));
        string referringURL = string.Empty;

        if (Request.Cookies["login"] != null)
        {
            HttpCookie aCookie = Request.Cookies["login"];
            referringURL = Server.HtmlEncode(aCookie.Value);
        }

        string guidSave = AddSessionToDatabase(referringURL);


        Response.Redirect(referringURL + "?guid=" + guidSave +
                    "&url=" + Server.HtmlEncode(returnURL).ToString());
        
        //Response.Redirect("http://localhost/UsesLogin/Default.aspx");

    }
    //This method adds the session information to the database and returns the GUID
    //  used to identify the data.
    private string AddSessionToDatabase(string urlIn)
    {

        //************************************
        //Enter connection information here

        SqlConnection con = new SqlConnection("Server=plesksql1.ehosting.com;Initial Catalog=members;User Id=codeup;Password=thargoid;Trusted_Connection=False;");

        //**************************************

        SqlCommand cmd = new SqlCommand();
        con.Open();
        cmd.Connection = con;
        int i = 0;
        string strSql, guidTemp = GetGuid();

        Session.Add("cu", "dangerZone");

        while (i < Session.Contents.Count)
        {
            strSql = "INSERT INTO ASPSessionState (GUID, SessionKey, SessionValue, ReferringUrl) " +
                "VALUES ('" + guidTemp + "', '" + Session.Contents.Keys[i].ToString() + "', '" +
                Session.Contents[i].ToString() + "', '" + urlIn + "')";
            cmd.CommandText = strSql;
            cmd.ExecuteNonQuery();
            i++;
        }

        con.Close();
        cmd.Dispose();
        con.Dispose();

        return guidTemp;
    }

    //This method returns a new GUID as a string.
    private string GetGuid()
    {
        return System.Guid.NewGuid().ToString();
    }

    protected void Login1_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                returnURL = Request.UrlReferrer.AbsoluteUri.Replace(Request.UrlReferrer.AbsolutePath, Request.QueryString["ReturnUrl"]);

                Response.Write(returnURL);
                Response.Write("<br/>" + Request.UrlReferrer.AbsolutePath);
                Response.Write("<br/>" + Request.UrlReferrer.Host);
                Response.Write("<br/>" + Request.UrlReferrer.PathAndQuery);
                Response.Write("<br/>" + Request.UrlReferrer.OriginalString);
                Response.Write("<br/><br/>" + returnURL);

                string referringURL = Request.UrlReferrer.AbsoluteUri;

                LoginErrorDetails.Text = referringURL;

                //Label1.Text = Request.QueryString["ReturnUrl"];
                HttpCookie appCookie = new HttpCookie("login");
                appCookie.Value = referringURL;
                appCookie.Expires = DateTime.Now.AddHours(1);
                Response.Cookies.Add(appCookie);

            }
            catch { }
        }
    }
}
