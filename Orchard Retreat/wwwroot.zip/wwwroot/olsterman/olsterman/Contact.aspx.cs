using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Mail;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace olsterman
{
    public class Globals
    {
        public Globals() { }

        public static string TEMPLATE_FILE = "templateFile";
        public static string SMS2EMAIL = "URL_SMS";
        public static string WEB_PROXY = "webProxy";
        public static string OLSTER_MOBILE = "olMobile";
        public static string ROG_MOBILE = "rbMobile";
        public static string SMS_USERNAME = "sms2email_username";
        public static string SMS_PASSWORD = "sms2email_pword";
    }

    public partial class Contact : System.Web.UI.Page
    {
        protected void btnSubmitEnquiry_Click(object sender, System.EventArgs e)
		{
			string name = txtName.Text.Trim();
			string phone = txtPhone.Text.Trim();
			string details = txtEnquiry.Text.Trim();

			if (name == string.Empty)
			{
				lblInfo.Text = "Please enter your name";
				return;
			}
			if (phone == string.Empty)
			{
				lblInfo.Text="Please enter your phone number";
				return;
			}
			if (details == string.Empty)
			{
				lblInfo.Text = "Please enter details of enquiry";
				return;
			}

			string msg = name + Environment.NewLine +
							phone + Environment.NewLine + 
							ddEnquiryAbout.SelectedValue + Environment.NewLine + 
							details;
			//send email first
			try
			{
				MailMessage mail = new MailMessage();
				mail.To="norrisandson@hotmail.com";
				mail.From="website@norrisandson.co.uk";
				mail.Cc="olsterman@trashmail.net"; //send copy to rog
				mail.BodyFormat=MailFormat.Text;

				mail.Subject="Someone used the website!";
				mail.Body=msg;
				SmtpMail.SmtpServer="localhost";
				SmtpMail.Send(mail);
			}
			catch
			{
				//mail failed for some reason
			}

			string smsUser = ConfigurationSettings.AppSettings.Get(Globals.SMS_USERNAME);
			string smsPword = ConfigurationSettings.AppSettings.Get(Globals.SMS_PASSWORD);

#if DEBUG
			string olMobile = ConfigurationSettings.AppSettings.Get(Globals.ROG_MOBILE);
#else
			string olMobile = ConfigurationSettings.AppSettings.Get(Globals.OLSTER_MOBILE);
#endif

			string paras = "username=" + smsUser + "&password=" + smsPword + "&to_num=" + olMobile + "&message=" + msg + "&flash=0";

			//all good - send text to olly
			HTTP_Post postSMS = new HTTP_Post(ConfigurationSettings.AppSettings.Get(Globals.SMS2EMAIL), paras);

			string response;

			if (!postSMS.Post(out response))
			{
				lblInfo.Text = "Message failed";
			}
			else
			{
				//response codes on page http://www.sms2email.com/site/developerinfo2.php
				if (response.Trim().ToUpper() == "AQSMS-OK")
				lblInfo.Text = "Message sent";
			}
		}		
    }
}
