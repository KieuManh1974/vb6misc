using System;
using System.Net;
using System.IO;
using System.Text;
using System.Configuration;

namespace olsterman
{
    /// <summary>
    /// Summary description for HTTP_Post.
    /// </summary>
    /// from http://en.csharp-online.net/HTTP_Post

    public class HTTP_Post
    {
        private string _uri;
        private string _parameters;
        private string _lastError = string.Empty;

        public HTTP_Post(string uri, string parameters)
        {
            _uri = uri;
            _parameters = parameters;
        }

        public string LastError
        {
            get
            {
                return _lastError;
            }
        }

        public bool Post(out string response)
        {
            /*
            MSXML2.ServerXMLHTTP40Class http = new MSXML2.ServerXMLHTTP40Class();
            http.open ("POST",_uri,false,null,null);
            http.setRequestHeader ("Content-Type","application/x-www-form-urlencoded");
            http.send (_parameters);
			

            response = http.responseText;
            return true;
            */
            response = string.Empty;
            bool success = true;
            // parameters: name1=value1&name2=value2	

            WebRequest webRequest = WebRequest.Create(_uri);
            // make a Web request, after setting ABN's proxy credentials
#if DEBUG
            /*
			System.Net.WebProxy wp = new System.Net.WebProxy(ConfigurationSettings.AppSettings.Get(Globals.WEB_PROXY),true);
			string ProxyString = 
			   System.Configuration.ConfigurationManager.AppSettings
			   [GetConfigKey("proxy")];
			webRequest.Proxy = new WebProxy (ProxyString, true);
			*/
            System.Net.WebProxy wp = System.Net.WebProxy.GetDefaultProxy();
#else
			System.Net.WebProxy wp =System.Net.WebProxy.GetDefaultProxy();
#endif

            //System.Net.ServicePointManager.Expect100Continue = false;


            //Commenting out above required change to App.Config
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.Method = "POST";
            webRequest.Proxy = wp;
            webRequest.Timeout = 5000; //5 seconds

            byte[] bytes = Encoding.ASCII.GetBytes(_parameters);
            Stream os = null;
            try
            { // send the Post
                webRequest.ContentLength = bytes.Length;   //Count bytes to send
                os = webRequest.GetRequestStream();
                os.Write(bytes, 0, bytes.Length);         //Send it
            }
            catch (WebException ex)
            {
                success = false;
                _lastError = ex.Message;
            }
            finally
            {
                if (os != null)
                {
                    os.Close();
                }
            }

            try
            { // get the response
                WebResponse webResponse = webRequest.GetResponse();
                if (webResponse == null)
                { return false; }
                StreamReader sr = new StreamReader(webResponse.GetResponseStream());
                response = sr.ReadToEnd().Trim();
            }
            catch (WebException ex)
            {
                success = false;
                _lastError = ex.Message;
            }

            return success;

        } // end HttpPost 

    }
}
