﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Web.UI;

[assembly: AssemblyTitle("ObfuscatedEmailLink")]
[assembly: AssemblyDescription("ASP.NET Hyperlink to obfuscate mailto: links")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("CodeUp")]
[assembly: AssemblyProduct("ObfuscatedEmailLink")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
