using System;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls;
[assembly: TagPrefix("RBGP.WebControls", "rbgp")]

namespace RBGP.WebControls
{
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:EmailLink runat=server></{0}:EmailLink>")]
    public class EmailLink : HyperLink
    {
        private string HtmlObfuscate(string text)
        {
            string tempHtmlObfuscate = null;
            int i = 0;
            int acode = 0;
            string repl = "";
            tempHtmlObfuscate = text;
            for (i = tempHtmlObfuscate.Length; i >= 1; i--)
            {
                acode = Convert.ToInt32(tempHtmlObfuscate[i - 1]);
                if (acode == 32)
                {
                    repl = " ";
                }
                else if (acode == 34)
                {
                    repl = "\"";
                }
                else if (acode == 38)
                {
                    repl = "&";
                }
                else if (acode == 60)
                {
                    repl = "<";
                }
                else if (acode == 62)
                {
                    repl = ">";
                }
                else if (acode >= 32 && acode <= 127)
                {
                    repl = "&#" + Convert.ToString(acode) + ";";
                }
                else
                {
                    repl = "&#" + Convert.ToString(acode) + ";";
                }
                if (repl.Length > 0)
                {
                    tempHtmlObfuscate = tempHtmlObfuscate.Substring(0, i - 1) +
                                        repl + tempHtmlObfuscate.Substring(i);
                    repl = "";
                }
            }
            return tempHtmlObfuscate;
        }


        protected override void Render(HtmlTextWriter writer)
        {
            HyperLink link = this;
            writer.Write("<a");
            if (!string.IsNullOrEmpty(link.NavigateUrl))
            {
                if (link.NavigateUrl.StartsWith("~"))
                    writer.WriteAttribute("href", link.ResolveClientUrl(link.NavigateUrl));
                else if (link.NavigateUrl.StartsWith("mailto:"))
                {
                    link.NavigateUrl = HtmlObfuscate(link.NavigateUrl);
                    writer.WriteAttribute("href", link.NavigateUrl);
                }
                else
                {
                    writer.WriteAttribute("href", link.NavigateUrl);
                }
            }

            if (!string.IsNullOrEmpty(link.CssClass))
                writer.WriteAttribute("class", link.CssClass);

            if (!string.IsNullOrEmpty(link.Target))
                writer.WriteAttribute("target", link.Target);

            foreach (string key in link.Attributes.Keys)
                writer.WriteAttribute(key, link.Attributes[key]);

            writer.Write(">");

            RenderContents(writer);
            writer.Write("</a>");
        }

        protected override void RenderContents(HtmlTextWriter output)
        {
            output.Write(Text);
        }
    }
}