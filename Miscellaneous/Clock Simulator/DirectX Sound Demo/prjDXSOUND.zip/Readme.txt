NOTE:  TO RUN THIS APPLICATION ON A WINDOWS 95/98, YOU MUST HAVE DIRECTX 7 INSTALLED.  IF YOU DON'T ALREADY HAVE IT INSALLED, YOU CAN DOWNLOAD IT FROM http://www.microsoft.com/downloads/release.asp?ReleaseID=16819.  FOR WINDOWS NT WITH THE LATEST SERVICE PACK AND WINDOWS 2000, this download should not be necessary.  

This application of example shows the use of the DirectSounds for the creation of audio applications. 	In this project some of the characteristics of DirectSound are implemented as: the execution more sounds contemporarily, the three-dimensional positioning of the sound in the space, the creation of events with directx7 etc.  
In the example reference is made to some Api of Window to receive information on the wave File in way to represent it graphically.  
To have more information to refer to the SDK of the Microsoft.  
