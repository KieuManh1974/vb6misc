A very simple example of Neural Networks using back propagation

This program is a simple example of Neural Networks using back propagation. My code has all basic functionalities like learning rate, load net, save net, etc. You can have as many layers as you can. The code here is extensible ie you can use my code in your programs to implement neural networks. Here a sample problem and network is given. Load the network with name "XOR.nn". It solves XOR problem. 'Please don't forget to give comments, credits and most important your VOTE!. And note if Neural Networks and back propagation is a mystery for you I can write a tutorial on nn and back propagation. Just tell me, if you want it, via feedback. And also, if you create another application using my neural networks please inform me.


MadeBy:
Paras Chopra
CEO, NaramCheez
paraschopra@lycos.com
http://naramcheez.netfirms.com