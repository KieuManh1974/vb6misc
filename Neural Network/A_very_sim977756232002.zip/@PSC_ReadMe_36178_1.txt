Title: A very simple example of Neural Networks using back propagation
Description: A very simple example of Neural Networks using back propagation
This program is a simple example of Neural Networks using back propagation. My code has all basic functionalities like learning rate, load net, save net, etc. You can have as many layers as you can. The code here is extensible ie you can use my code in your programs to implement neural networks. Here a sample problem and network is given. Load the network with name "XOR.nn". It solves XOR problem. 'Please don't forget to give comments, credits and most important your VOTE!. And note if Neural Networks and back propagation is a mystery for you I can write a tutorial on nn and back propagation. Just tell me, if you want it, via feedback. And also, if you create another application using my neural networks please inform me.

MadeBy:
Paras Chopra
CEO, NaramCheez
paraschopra@lycos.com
http://naramcheez.netfirms.com
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=36178&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
